// Keep this empty when the API is served from the same domain.
// For a separate API host, use its HTTPS origin, for example: "https://api.example.com"
window.OTHMAN_API_BASE_URL = "";
