(() => {
  const base = String(window.OTHMAN_API_BASE_URL || "").replace(/\/+$/, "");
  async function request(path, options = {}) {
    const response = await fetch(base + "/api/v1" + path, {
      method: options.method || "GET",
      credentials: "include",
      headers: options.body === undefined ? (options.headers || {}) : Object.assign({ "Content-Type": "application/json" }, options.headers || {}),
      body: options.body === undefined ? undefined : JSON.stringify(options.body)
    });
    const type = response.headers.get("content-type") || "";
    const payload = type.includes("application/json") ? await response.json() : await response.blob();
    if (!response.ok) { const error = new Error(payload && payload.error ? payload.error : "تعذر الاتصال بالخادم."); error.status = response.status; throw error; }
    return payload;
  }
  window.StoreAPI = {
    baseUrl: base,
    request,
    config: () => request("/config"),
    products: () => request("/products"),
    me: () => request("/me"),
    login: body => request("/auth/login", { method: "POST", body }),
    register: body => request("/auth/register", { method: "POST", body }),
    logout: () => request("/auth/logout", { method: "POST", body: {} }),
    order: body => request("/orders", { method: "POST", body }),
    deposit: body => request("/deposits", { method: "POST", body }),
    ticket: body => request("/tickets", { method: "POST", body })
  };
})();
