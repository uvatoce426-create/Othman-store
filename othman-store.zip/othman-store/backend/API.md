# REST API v1

Base path: `/api/v1`. JSON responses use UTF-8. Customer/admin sessions use the server's HTTP-only cookie.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | API status |
| GET | `/config` | Store contact and Sham Cash details |
| GET | `/products` | Active product catalog |
| GET | `/products/:id-or-slug` | One active product |
| POST | `/auth/register` | Create customer account |
| POST | `/auth/login` | Customer sign-in |
| POST | `/auth/logout` | End current session |
| GET | `/me` | Current balance, orders and deposits |
| POST | `/orders` | Create order; server recalculates prices |
| POST | `/deposits` | Submit pending Sham Cash deposit and optional receipt |
| POST | `/tickets` | Submit customer inquiry |
| POST | `/admin/login` | Admin sign-in |
| GET | `/admin/overview` | Products, orders, customers, deposits, finance, tickets and settings |
| POST/PUT/DELETE | `/admin/products[/:id]` | Manage product catalog |
| POST | `/admin/upload-image` | Upload a PNG/JPG/WebP image (maximum 3 MB) as admin |
| PATCH | `/admin/orders/:id` | Update order/payment/delivery statuses |
| PATCH | `/admin/deposits/:id` | Approve or reject a pending deposit |
| GET | `/admin/deposits/:id/receipt` | View a private receipt as admin |
| PATCH | `/admin/tickets/:id` | Open/close a support request |
| PUT | `/admin/settings` | Update store settings and category image paths |

`POST /orders` requires a signed-in customer session. Input includes `items: [{productId,optionIndex,quantity,playerId,server,username,accountEmail}]` and `paymentMethod: "wallet" | "shamcash"`. The server uses the signed-in profile, ignores client-supplied prices, and rejects wallet purchases when the balance is insufficient. The storefront creates a wallet order directly from the Buy button.

`POST /deposits` requires a signed-in customer session. It accepts a required `amount` (0.01–5000 USD), a required `reference` (Sham Cash operation number), and optional `receiptData` (PNG/JPG/WebP data URL). The request stays pending; an admin can confirm or adjust the amount when approving it, and only then does the server credit the wallet.

Admin product forms include a unit cost. Paid orders capture that cost at purchase time, so the finance report can calculate recorded profit without changing historical order costs. Profit excludes products without a recorded cost.

The image upload endpoint accepts a JSON imageData data URL and returns a public /assets/uploads path. Product edits can use that path; category image overrides are stored in admin settings under their category IDs.
