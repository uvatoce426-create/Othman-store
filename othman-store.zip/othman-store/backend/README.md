# Backend and admin

The built-in Node.js server serves the storefront and provides the REST API. It uses only Node's standard library; no database server or npm dependencies are required for the local starter.

## Run locally

1. Install Node.js 18 or newer.
2. Copy `backend/.env.example` to `backend/.env`.
3. Set a unique `ADMIN_USERNAME` and a strong `ADMIN_PASSWORD` in that file.
4. From this folder, run `npm start`.
5. Open `http://localhost:4173` for the store and `http://localhost:4173/admin.html` for admin.

The API defaults to port 4173. Store data is persisted in `backend/data/store.json`; uploaded Sham Cash receipts are kept privately in `backend/private/receipts/` and are visible only to authenticated admins.

## API base and remote hosting

The frontend reads `window.OTHMAN_API_BASE_URL` from `api-config.js`. Leave it empty when the API shares the storefront origin. For a separate HTTPS API host, enter its origin there and set `FRONTEND_ORIGIN` in `backend/.env` to the exact public frontend origin. Use HTTPS for production so secure session cookies work. A same-origin reverse proxy is the simplest production deployment.

## Included server functions

- Public catalog and store contact details.
- Customer registration and sign-in with scrypt password hashes and HTTP-only sessions.
- Server-priced order creation; wallet orders require sign-in and sufficient server-side balance.
- Sham Cash deposit requests with a required amount and transaction reference, plus an optional private image receipt; deposits stay pending until an admin approves or rejects them.
- Contact form submissions stored as support tickets.
- Admin product create, edit and delete; customer details and counts; recorded-cost profit reporting; order status/payment updates; deposit approval/rejection; support ticket closure; contact/account settings.
- API input checks, login rate limits, same-origin protection, private receipt access, and basic browser security headers.

## Production notes

This is a usable single-process starter, not a hardened multi-instance commerce deployment. Before public launch, put it behind HTTPS, choose managed durable database and private object storage, back up customer data, set a strong admin password, and connect the actual supplier/payment workflows. The sample product prices and availability are placeholders. Never put admin credentials in frontend files.
