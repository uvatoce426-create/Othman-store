const base='http://127.0.0.1:4175';
(async()=>{
 const login=await fetch(base+'/api/v1/admin/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:'qa-admin',password:'qa-test-password-not-for-use'})});
 const cookie=(login.headers.get('set-cookie')||'').split(';')[0];
 if(login.status!==200||!cookie)throw Error('admin login failed: '+login.status);
 const imageData='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+c2TcAAAAASUVORK5CYII=';
 const upload=await fetch(base+'/api/v1/admin/upload-image',{method:'POST',headers:{'content-type':'application/json',cookie},body:JSON.stringify({imageData})});
 const uploaded=await upload.json();
 if(upload.status!==201||!uploaded.image)throw Error('image upload failed: '+upload.status+' '+JSON.stringify(uploaded));
 const save=await fetch(base+'/api/v1/admin/settings',{method:'PUT',headers:{'content-type':'application/json',cookie},body:JSON.stringify({categoryImages:{games:uploaded.image}})});
 const settings=await save.json();
 if(save.status!==200||settings.settings.categoryImages.games!==uploaded.image)throw Error('category image save failed: '+save.status);
 const asset=await fetch(base+uploaded.image);
 if(asset.status!==200||asset.headers.get('content-type')!=='image/png')throw Error('uploaded asset was not served as PNG: '+asset.status);
 console.log(JSON.stringify({adminLogin:login.status,upload:upload.status,categorySettings:save.status,asset:asset.status,mime:asset.headers.get('content-type')}));
})().catch(error=>{console.error(error.message);process.exitCode=1});
