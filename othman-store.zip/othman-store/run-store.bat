@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install the current LTS from https://nodejs.org/
  pause
  exit /b 1
)
if not exist "backend\.env" (
  copy "backend\.env.example" "backend\.env" >nul
  echo Set ADMIN_USERNAME and ADMIN_PASSWORD in backend\.env before using the admin panel.
  notepad "backend\.env"
)
echo Store: http://localhost:4173
echo Admin: http://localhost:4173/admin.html
echo Keep this window open while using the store. Press Ctrl+C to stop.
node backend\server.js
echo.
echo The store server has stopped.
pause
