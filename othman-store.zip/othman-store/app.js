(() => {
  "use strict";

  // All uploaded artwork lives here so images can be replaced without editing the views.
  const ASSETS = {
    mark: "assets/images/brand-mark.jpg",
    wordmark: "assets/images/brand-wordmark.jpg",
    hero: "assets/source/5.jpeg",
    giftCards: "assets/images/product-cards.jpg",
    subscriptions: "assets/images/product-subscriptions.jpg",
    steam: "assets/images/product-cards.jpg",
    community: "assets/images/whatsapp-community.jpg",
    categories: {
      games: "assets/images/category-games.jpg",
      chat: "assets/images/category-chat.jpg",
      wallet: "assets/images/category-wallet.jpg",
      social: "assets/images/category-social.jpg",
      subscriptions: "assets/images/category-subscriptions.jpg",
      cards: "assets/images/category-cards.jpg"
    },
    communityUrl: "https://chatdUQ5Ujp6D.whatsapp.com/FYcQb5xtDc319",
    supportUrl: "https://wa.me/963992761983",
    socialLinks: { telegram: "", instagram: "", facebook: "", tiktok: "" }
  };

  // Add the store's verified Sham Cash details and current exchange rate before accepting real deposits.
  const SHAM_CASH = { recipientName: "OTHMAN STORE", walletNumber: "cfef2a9887eb9a804eaafed30d4edd21", exchangeRateSypPerUsd: 0 };

  const COPY = {
    ar: {
      announcement: "متجرك الرقمي للألعاب والاشتراكات والبطاقات", seeOffers: "اكتشف العروض", home: "الرئيسية", categories: "الأقسام", products: "المنتجات", offers: "العروض", support: "الدعم", protection: "الحماية", about: "من نحن", search: "ابحث عن لعبة أو بطاقة أو خدمة...", notifications: "الإشعارات", wallet: "الرصيد", account: "الحساب", cart: "السلة", favorites: "المفضلة", orders: "طلباتي", signIn: "تسجيل الدخول", signUp: "إنشاء حساب", signOut: "تسجيل الخروج", heroEyebrow: "كل عالمك الرقمي في مكان واحد", heroTitle: "ابدأ مغامرتك الرقمية", heroText: "شحن ألعاب • بطاقات رقمية • اشتراكات • خدمات رقمية", shopNow: "تسوق الآن", browseCategories: "استكشف الأقسام", popularCategories: "تسوق حسب القسم", popularCategoriesText: "اختر وجهتك، واكتشف كل ما تحتاجه لعالمك الرقمي.", allCategories: "كل الأقسام", featured: "اختياراتنا لك", featuredText: "منتجات رقمية مختارة بعناية لعشاق الألعاب والتقنية.", seeAll: "عرض الكل", bestSellers: "الأكثر طلبًا", bestSellersText: "اختيارات يثق بها مجتمع OTHMAN STORE.", offerTitle: "عروض لفترة محدودة", offerText: "اكتشف عروضًا مختارة على الألعاب والاشتراكات والبطاقات.", browseDeals: "تصفح العروض", games: "الألعاب", giftCards: "البطاقات الرقمية", gameTopups: "شحن الألعاب", subscriptions: "الاشتراكات", communityTitle: "انضم إلى مجتمع الواتساب", communityText: "لمعرفة آخر الأخبار والعروض", joinNow: "انضم الآن", services: "تجربة تسوق رقمية أسهل", serviceDelivery: "تسليم رقمي", serviceDeliveryText: "تصل تفاصيل طلبك بعد إتمامه.", serviceSecure: "تجربة آمنة", serviceSecureText: "واجهة واضحة وخطوات شراء مرتبة.", serviceSupport: "دعم متواصل", serviceSupportText: "نحن هنا لمساعدتك عند الحاجة.", serviceChoice: "خيارات متنوعة", serviceChoiceText: "ألعاب وبطاقات وخدمات في مكان واحد.", faq: "الأسئلة الشائعة", faq1: "كيف أستلم طلبي الرقمي؟", faq1a: "ستظهر تفاصيل الطلب وحالته في صفحة طلباتي بعد تأكيده.", faq2: "هل أحتاج إلى إنشاء حساب؟", faq2a: "يمكنك التصفح وتسجيل الدخول لمتابعة الطلبات والمحفظة.", faq3: "كيف أتواصل مع الدعم؟", faq3a: "استخدم صفحة الدعم أو تواصل معنا عبر واتساب.", categoryGames: "الألعاب", categoryChat: "تطبيقات الدردشة", categoryWallet: "الرصيد والعملات", categoryCards: "البطاقات", categorySubscriptions: "الاشتراكات", categorySocial: "السوشيال ميديا", categoryVerification: "توثيق الحسابات", categoryAI: "الذكاء الاصطناعي", categoryDesign: "برامج التصميم", categoryVPN: "البروكسي و VPN", categoryMicrosoft: "خدمات مايكروسوفت", categoryPC: "برامج الكمبيوتر", categoryMobile: "شحن ألعاب الموبايل", categoryPlayStation: "PlayStation", categoryXbox: "Xbox", categorySteam: "Steam", categoryNintendo: "Nintendo", productCount: "منتج", details: "التفاصيل", addToCart: "اشتر الآن", buyNow: "اشتر الآن", instant: "تسليم رقمي", available: "متوفر", soldOut: "غير متوفر", sortPopular: "الأكثر شيوعًا", sortNewest: "الأحدث", sortPriceLow: "السعر: الأقل أولًا", sortPriceHigh: "السعر: الأعلى أولًا", sortDiscount: "الأعلى خصمًا", filterAll: "كل المنتجات", noResults: "لم نعثر على منتجات مطابقة", trySearch: "جرّب كلمة أخرى أو استكشف الأقسام.", category: "القسم", description: "الوصف", instructions: "طريقة الاستخدام", faqProduct: "أسئلة حول المنتج", related: "منتجات مشابهة", chooseOption: "اختر الفئة المناسبة", quantity: "الكمية", playerId: "معرّف اللاعب", server: "الخادم / المنطقة", username: "اسم المستخدم (اختياري)", enterPlayerId: "أدخل معرّف اللاعب", selectServer: "اختر المنطقة", itemAdded: "تمت إضافة المنتج إلى الطلب", completeTopup: "أدخل بيانات اللاعب لإكمال الشراء.", purchaseLoginNote: "سجّل الدخول لإتمام الشراء الفوري من رصيد محفظتك.", purchaseStarted: "جاري تأكيد الطلب…", walletOnlyPurchase: "الشراء المباشر يتم من رصيد المحفظة.", cartTitle: "سلة التسوق", emptyCart: "سلتك بانتظار أول اختيار", emptyCartText: "تصفح الأقسام وأضف المنتجات التي تناسبك إلى سلتك.", orderSummary: "ملخص الطلب", subtotal: "المجموع الفرعي", discount: "الخصم", total: "الإجمالي", promo: "رمز الخصم", apply: "تطبيق", remove: "حذف", saveLater: "احفظ للمفضلة", checkout: "متابعة الشراء", continueShopping: "متابعة التسوق", promoApplied: "تم تطبيق الخصم", promoInvalid: "رمز الخصم غير صالح", checkoutTitle: "إتمام الطلب", customerInfo: "بيانات العميل", serviceDetails: "تفاصيل المنتجات", payment: "طريقة الدفع", confirmation: "التأكيد", fullName: "الاسم الكامل", email: "البريد الإلكتروني", phone: "رقم الهاتف", next: "متابعة", back: "رجوع", paymentWallet: "رصيد المحفظة", paymentWalletText: "استخدم رصيدك المتاح في المتجر.", paymentTransfer: "تحويل شام كاش", paymentTransferText: "حوّل قيمة الطلب إلى حساب المتجر ثم أرسل الطلب للمراجعة.", paymentGateway: "دفع إلكتروني", paymentGatewayText: "بوابة الدفع تُربط عند تجهيز المتجر للإطلاق.", confirmOrder: "تأكيد الطلب", orderCreated: "تم تسجيل طلبك للمتابعة", orderNo: "رقم الطلب", pending: "قيد الانتظار", processing: "قيد المعالجة", completed: "مكتمل", canceled: "ملغي", viewOrders: "عرض طلباتي", orderHistory: "سجل الطلبات", noOrders: "لا توجد طلبات حتى الآن", noOrdersText: "ستظهر طلباتك هنا بعد إتمام عملية الشراء.", walletTitle: "محفظتك الرقمية", currentBalance: "الرصيد الحالي", addBalance: "إضافة رصيد", transactions: "سجل العمليات", noTransactions: "لا توجد عمليات مسجلة.", depositTitle: "طلب إضافة رصيد", amount: "المبلغ", sendRequest: "إرسال الطلب", depositPending: "تم تسجيل طلب الإضافة بحالة معلّقة للمعالجة.", demoDeposit: "تُراجع التحويلات قبل إضافة الرصيد إلى محفظتك.", accountTitle: "حسابي", profile: "الملف الشخصي", security: "الأمان", tickets: "تذاكر الدعم", referral: "دعوة الأصدقاء", signInText: "سجّل الدخول لمتابعة طلباتك ومفضلاتك.", password: "كلمة المرور", confirmPassword: "تأكيد كلمة المرور", remember: "تذكرني", forgot: "نسيت كلمة المرور؟", google: "المتابعة بحساب Google", or: "أو", haveAccount: "لديك حساب؟", noAccount: "ليس لديك حساب؟", demoAuth: "بيانات الحساب تحفظ على خادم المتجر ولا تخزن كلمة المرور نصيًا.", authSuccess: "تم تسجيل الدخول بنجاح", favoritesTitle: "قائمة المفضلة", emptyFavorites: "لم تحفظ منتجات بعد", supportTitle: "مركز الدعم", supportText: "أرسل استفسارك وسنساعدك في أقرب وقت.", contactWhatsApp: "تواصل عبر واتساب", openCommunity: "مجتمع واتساب", createTicket: "إرسال استفسار", subject: "عنوان الاستفسار", message: "اكتب رسالتك هنا...", ticketSaved: "تم إرسال الاستفسار إلى فريق المتجر", aboutTitle: "عالمك الرقمي يبدأ من هنا", aboutText: "OTHMAN STORE مساحة واحدة للألعاب والبطاقات الرقمية والاشتراكات والخدمات.", searchResults: "نتائج البحث", all: "الكل", priceRange: "نطاق السعر", maxPrice: "أقصى سعر", clear: "مسح", sortBy: "ترتيب حسب", notFound: "الصفحة غير موجودة", goHome: "العودة للرئيسية", orderDate: "التاريخ", orderItems: "المنتجات", orderStatus: "حالة الطلب", paymentStatus: "حالة الدفع", deliveryStatus: "التسليم", copy: "نسخ", copied: "تم النسخ", wishlist: "أضف للمفضلة", removeFavorite: "إزالة من المفضلة", viewAccount: "لوحة الحساب", menu: "القائمة", privacy: "سياسة الخصوصية", terms: "الشروط والأحكام", noBackend: "تعذر الاتصال بالمتجر، حاول مرة أخرى.", supportHours: "الدعم متاح يوميًا عبر قنوات التواصل.", invoice: "الفاتورة", faqAnswerOrder: "تظهر حالة كل طلب وتفاصيله من لوحة الحساب.", language: "English"
    },
    en: {
      announcement: "Your digital store for games, subscriptions and gift cards", seeOffers: "Explore offers", home: "Home", categories: "Categories", products: "Products", offers: "Offers", support: "Support", protection: "Security", about: "About", search: "Search games, cards or services...", notifications: "Notifications", wallet: "Wallet", account: "Account", cart: "Cart", favorites: "Favorites", orders: "My orders", signIn: "Sign in", signUp: "Create account", signOut: "Sign out", heroEyebrow: "Your digital world in one place", heroTitle: "Power up your digital world", heroText: "Game top-ups • Gift cards • Subscriptions • Digital services", shopNow: "Shop now", browseCategories: "Browse categories", popularCategories: "Shop by category", popularCategoriesText: "Choose a destination and find what you need for your digital world.", allCategories: "All categories", featured: "Picked for you", featuredText: "Digital essentials selected for gamers and tech fans.", seeAll: "View all", bestSellers: "Popular picks", bestSellersText: "Community favorites from OTHMAN STORE.", offerTitle: "Limited-time offers", offerText: "Find selected deals on games, subscriptions and cards.", browseDeals: "Browse deals", games: "Games", giftCards: "Gift cards", gameTopups: "Game top-ups", subscriptions: "Subscriptions", communityTitle: "Join our WhatsApp community", communityText: "Get the latest news and offers", joinNow: "Join now", services: "A simpler digital shopping experience", serviceDelivery: "Digital delivery", serviceDeliveryText: "Order details appear after confirmation.", serviceSecure: "A clear experience", serviceSecureText: "A simple flow with clear purchase steps.", serviceSupport: "Ongoing support", serviceSupportText: "We are here when you need help.", serviceChoice: "More to choose from", serviceChoiceText: "Games, cards and services in one place.", faq: "Frequently asked questions", faq1: "How do I receive a digital order?", faq1a: "Your order details and status appear on the orders page after confirmation.", faq2: "Do I need an account?", faq2a: "Sign in to track orders and manage your wallet.", faq3: "How can I contact support?", faq3a: "Use the support page or contact us on WhatsApp.", categoryGames: "Games", categoryChat: "Chat apps", categoryWallet: "Balance & coins", categoryCards: "Gift cards", categorySubscriptions: "Subscriptions", categorySocial: "Social media", categoryVerification: "Account services", categoryAI: "AI services", categoryDesign: "Design tools", categoryVPN: "Proxy & VPN", categoryMicrosoft: "Microsoft services", categoryPC: "PC software", categoryMobile: "Mobile game top-ups", categoryPlayStation: "PlayStation", categoryXbox: "Xbox", categorySteam: "Steam", categoryNintendo: "Nintendo", productCount: "items", details: "Details", addToCart: "Buy now", buyNow: "Buy now", instant: "Digital delivery", available: "Available", soldOut: "Unavailable", sortPopular: "Most popular", sortNewest: "Newest", sortPriceLow: "Price: low to high", sortPriceHigh: "Price: high to low", sortDiscount: "Biggest discount", filterAll: "All products", noResults: "No matching products", trySearch: "Try another search or browse categories.", category: "Category", description: "Description", instructions: "How it works", faqProduct: "Product questions", related: "Related products", chooseOption: "Choose an option", quantity: "Quantity", playerId: "Player ID", server: "Server / region", username: "Username (optional)", enterPlayerId: "Enter player ID", selectServer: "Choose a region", itemAdded: "Added to your order", completeTopup: "Enter your player details to continue.", purchaseLoginNote: "Sign in to place an instant order using your wallet balance.", purchaseStarted: "Confirming your order…", walletOnlyPurchase: "Direct purchases use your wallet balance.", cartTitle: "Your cart", emptyCart: "Your cart is ready for a first pick", emptyCartText: "Browse categories and add something you like.", orderSummary: "Order summary", subtotal: "Subtotal", discount: "Discount", total: "Total", promo: "Promo code", apply: "Apply", remove: "Remove", saveLater: "Save to favorites", checkout: "Continue to checkout", continueShopping: "Continue shopping", promoApplied: "Discount applied", promoInvalid: "That code is not valid", checkoutTitle: "Checkout", customerInfo: "Customer details", serviceDetails: "Product details", payment: "Payment method", confirmation: "Confirmation", fullName: "Full name", email: "Email", phone: "Phone number", next: "Continue", back: "Back", paymentWallet: "Wallet balance", paymentWalletText: "Use your available store balance.", paymentTransfer: "Sham Cash transfer", paymentTransferText: "Transfer the order total to the store account.", paymentGateway: "Online payment", paymentGatewayText: "Connect a payment gateway before launch.", confirmOrder: "Place order", orderCreated: "Your order is registered for processing", orderNo: "Order number", pending: "Pending", processing: "Processing", completed: "Completed", canceled: "Canceled", viewOrders: "View my orders", orderHistory: "Order history", noOrders: "No orders yet", noOrdersText: "Your orders will appear here after checkout.", walletTitle: "Your digital wallet", currentBalance: "Current balance", addBalance: "Add funds", transactions: "Transactions", noTransactions: "No transactions recorded.", depositTitle: "Request a balance top-up", amount: "Amount", sendRequest: "Send request", depositPending: "Your top-up request is saved as pending.", demoDeposit: "Transfers are reviewed before funds are added to your wallet.", accountTitle: "My account", profile: "Profile", security: "Security", tickets: "Support tickets", referral: "Invite friends", signInText: "Sign in to track orders and favorites.", password: "Password", confirmPassword: "Confirm password", remember: "Remember me", forgot: "Forgot password?", google: "Continue with Google", or: "or", haveAccount: "Already have an account?", noAccount: "New here?", demoAuth: "Your account data is saved on the store server; passwords are never stored as plain text.", authSuccess: "You are signed in", favoritesTitle: "Your favorites", emptyFavorites: "No saved products yet", supportTitle: "Support center", supportText: "Send a question and we will help as soon as we can.", contactWhatsApp: "Contact on WhatsApp", openCommunity: "WhatsApp community", createTicket: "Send a question", subject: "Subject", message: "Write your message...", ticketSaved: "Your question was sent to the store team", searchResults: "Search results", all: "All", priceRange: "Price range", maxPrice: "Maximum price", clear: "Clear", sortBy: "Sort by", notFound: "Page not found", goHome: "Back to home", orderDate: "Date", orderItems: "Items", orderStatus: "Order status", paymentStatus: "Payment status", deliveryStatus: "Delivery", copy: "Copy", copied: "Copied", wishlist: "Save to favorites", removeFavorite: "Remove from favorites", viewAccount: "Account dashboard", menu: "Menu", privacy: "Privacy policy", terms: "Terms & conditions", noBackend: "Store connection is unavailable. Please try again.", supportHours: "Support is available daily through our contact channels.", invoice: "Invoice", faqAnswerOrder: "Check your account dashboard for order details and status.", language: "العربية"
    }
  };

  const WALLET_COPY = {
    ar: {
      shamCashTitle: "إيداع عبر شام كاش", shamCashSubtitle: "حوّل إلى محفظة المتجر ثم أرسل بيانات العملية للمراجعة.", shamCashNumber: "رقم محفظة المتجر", shamCashSetup: "أضف رقم محفظة شام كاش وسعر الصرف المعتمد في إعدادات المتجر قبل استقبال تحويلات حقيقية.", shamCashRateMissing: "سعر الصرف غير مضبوط؛ تواصل مع المتجر قبل التحويل.", shamCashAmount: "الرصيد المراد إضافته بالدولار", shamCashEstimate: "المبلغ المطلوب تحويله تقريبًا بالليرة السورية", shamCashRecipient: "اسم المستلم", shamCashSender: "رقم شام كاش المحوِّل", shamCashReference: "رقم الحوالة / العملية", shamCashReceipt: "صورة الإيصال (اختياري)", shamCashReceiptNote: "سيظهر الإيصال لفريق الإدارة لمراجعة عملية التحويل.", shamCashStep1: "حوّل المبلغ المقابل بالليرة حسب السعر المعتمد الظاهر؛ إن لم يظهر سعر، تواصل مع المتجر قبل التحويل.", shamCashStep2: "أدخل رقم العملية؛ صورة الإيصال اختيارية.", shamCashStep3: "أرسل الطلب وانتظر المراجعة؛ لا يضاف الرصيد قبل تأكيد التحويل.", shamCashCopy: "نسخ الرقم", shamCashCopied: "تم نسخ الرقم", shamCashCopyFailed: "انسخ الرقم يدويًا", walletPayReady: "رصيدك يغطي قيمة الطلب.", walletInsufficient: "رصيد المحفظة لا يكفي لإتمام هذا الطلب.", walletShort: "المبلغ الناقص", walletPurchase: "شراء من المحفظة", walletDeposit: "طلب إيداع شام كاش"
    },
    en: {
      shamCashTitle: "Deposit with Sham Cash", shamCashSubtitle: "Transfer to the store wallet and submit the transfer details for review.", shamCashNumber: "Store wallet number", shamCashSetup: "Add the verified Sham Cash wallet number and exchange rate in the store settings before accepting real transfers.", shamCashRateMissing: "The exchange rate is not set. Contact the store before transferring.", shamCashAmount: "Wallet credit amount in USD", shamCashEstimate: "Approximate amount to transfer in Syrian pounds", shamCashRecipient: "Recipient name", shamCashSender: "Sender's Sham Cash number", shamCashReference: "Transfer reference", shamCashReceipt: "Transfer receipt (optional)", shamCashReceiptNote: "The receipt will be available to the store team to review the transfer.", shamCashStep1: "Transfer the Syrian pound equivalent at the displayed rate. If no rate appears, contact the store first.", shamCashStep2: "Enter the transfer reference; the receipt image is optional.", shamCashStep3: "Submit the request and wait for review; funds are added only after confirmation.", shamCashCopy: "Copy number", shamCashCopied: "Number copied", shamCashCopyFailed: "Copy the number manually", walletPayReady: "Your balance covers this order.", walletInsufficient: "Your wallet balance is not enough for this order.", walletShort: "Amount still needed", walletPurchase: "Wallet purchase", walletDeposit: "Sham Cash deposit request"
    }
  };

  const CATEGORIES = [
    { id: "games", key: "categoryGames", icon: "🎮", image: ASSETS.categories.games, desc: { ar: "PUBG وFree Fire والمزيد", en: "PUBG, Free Fire and more" } },
    { id: "chat", key: "categoryChat", icon: "💬", image: ASSETS.categories.chat, desc: { ar: "Telegram وخدمات الدردشة", en: "Telegram and chat services" } },
    { id: "wallet", key: "categoryWallet", icon: "💳", image: ASSETS.categories.wallet, desc: { ar: "رصيد وعملات رقمية", en: "Digital balances and coins" } },
    { id: "cards", key: "categoryCards", icon: "🎁", image: ASSETS.categories.cards, desc: { ar: "بطاقات المنصات والألعاب", en: "Platform and game cards" } },
    { id: "subscriptions", key: "categorySubscriptions", icon: "✦", image: ASSETS.categories.subscriptions, desc: { ar: "اشتراكات وترفيه رقمي", en: "Subscriptions and digital entertainment" } },
    { id: "social", key: "categorySocial", icon: "◉", image: ASSETS.categories.social, desc: { ar: "خدمات المنصات الاجتماعية", en: "Social platform services" } },
    { id: "verification", key: "categoryVerification", icon: "✓", image: ASSETS.categories.chat, desc: { ar: "خدمات الحسابات الرقمية", en: "Digital account services" } },
    { id: "ai", key: "categoryAI", icon: "✳", image: ASSETS.categories.social, desc: { ar: "أدوات الذكاء الاصطناعي", en: "AI tools and services" } },
    { id: "design", key: "categoryDesign", icon: "✎", image: ASSETS.categories.subscriptions, desc: { ar: "برامج التصميم والإبداع", en: "Design and creative tools" } },
    { id: "vpn", key: "categoryVPN", icon: "◇", image: ASSETS.categories.wallet, desc: { ar: "حماية واتصال رقمي", en: "Privacy and digital access" } },
    { id: "microsoft", key: "categoryMicrosoft", icon: "▦", image: ASSETS.categories.cards, desc: { ar: "خدمات Microsoft", en: "Microsoft services" } },
    { id: "pc", key: "categoryPC", icon: "▣", image: ASSETS.categories.games, desc: { ar: "برامج وأدوات الكمبيوتر", en: "PC software and tools" } },
    { id: "mobile", key: "categoryMobile", icon: "📱", image: ASSETS.categories.games, desc: { ar: "شحن ألعاب الموبايل", en: "Mobile game top-ups" } },
    { id: "playstation", key: "categoryPlayStation", platform: "PlayStation", icon: "◉", image: ASSETS.categories.cards, desc: { ar: "بطاقات وخدمات PlayStation", en: "PlayStation cards and services" } },
    { id: "xbox", key: "categoryXbox", platform: "Xbox", icon: "✕", image: ASSETS.categories.subscriptions, desc: { ar: "بطاقات واشتراكات Xbox", en: "Xbox cards and subscriptions" } },
    { id: "steam", key: "categorySteam", platform: "Steam", icon: "◉", image: ASSETS.sourceSteam || "assets/source/4.jpeg", desc: { ar: "بطاقات Steam والخدمات", en: "Steam cards and services" } },
    { id: "nintendo", key: "categoryNintendo", platform: "Nintendo", icon: "▣", image: ASSETS.categories.cards, desc: { ar: "بطاقات Nintendo الرقمية", en: "Nintendo digital cards" } }
  ];
  const DEFAULT_CATEGORY_IMAGES = Object.fromEntries(CATEGORIES.map((category) => [category.id, category.image]));

  // Prices and catalog entries are sample data for the preview; replace this array with the store API.
  let PRODUCTS = [
    { id: "p-pubg", slug: "pubg-uc", category: "games", title: { ar: "شدات PUBG Mobile", en: "PUBG Mobile UC" }, description: { ar: "اشحن رصيدك داخل اللعبة بسرعة وسهولة.", en: "Top up your in-game balance with ease." }, image: "assets/products/pubg-uc.svg", price: 1.49, oldPrice: 1.89, discount: 21, stock: 30, featured: true, bestSeller: true, instant: true, kind: "topup", platform: "Mobile", region: "Global", options: [{ ar: "60 UC", en: "60 UC", price: 1.49 }, { ar: "325 UC", en: "325 UC", price: 6.49 }, { ar: "660 UC", en: "660 UC", price: 12.99 }] },
    { id: "p-freefire", slug: "free-fire-diamonds", category: "games", title: { ar: "جواهر Free Fire", en: "Free Fire Diamonds" }, description: { ar: "جواهر للعبتك المفضلة مع تسليم رقمي.", en: "Diamonds for your favorite game." }, image: "assets/products/free-fire-diamonds.svg", price: 1.25, oldPrice: 1.55, discount: 19, stock: 22, featured: true, bestSeller: true, instant: true, kind: "topup", platform: "Mobile", region: "Global", options: [{ ar: "100 جوهرة", en: "100 diamonds", price: 1.25 }, { ar: "310 جواهر", en: "310 diamonds", price: 3.75 }, { ar: "520 جوهرة", en: "520 diamonds", price: 6.25 }] },
    { id: "p-steam", slug: "steam-wallet", category: "cards", title: { ar: "بطاقة Steam Wallet", en: "Steam Wallet Card" }, description: { ar: "اختر قيمة البطاقة المناسبة لحسابك.", en: "Choose a balance for your Steam account." }, image: "assets/products/steam-wallet.svg", price: 5.79, oldPrice: 6.49, discount: 11, stock: 18, featured: true, bestSeller: true, instant: true, kind: "digital", platform: "Steam", region: "Global", options: [{ ar: "$5", en: "$5", price: 5.79 }, { ar: "$10", en: "$10", price: 10.99 }, { ar: "$20", en: "$20", price: 21.5 }] },
    { id: "p-psn", slug: "playstation-gift-card", category: "cards", title: { ar: "بطاقة PlayStation Store", en: "PlayStation Store Card" }, description: { ar: "بطاقة رقمية لألعاب وإضافات PlayStation.", en: "Digital credit for games and add-ons." }, image: "assets/products/playstation-gift-card.svg", price: 11.49, oldPrice: 12.99, discount: 12, stock: 15, featured: true, bestSeller: false, instant: true, kind: "digital", platform: "PlayStation", region: "US", options: [{ ar: "$10 US", en: "$10 US", price: 11.49 }, { ar: "$25 US", en: "$25 US", price: 27.99 }, { ar: "$50 US", en: "$50 US", price: 55.99 }] },
    { id: "p-netflix", slug: "netflix-premium", category: "subscriptions", title: { ar: "اشتراك Netflix", en: "Netflix subscription" }, description: { ar: "اختر مدة الاشتراك المناسبة لك.", en: "Select a subscription period." }, image: "assets/products/netflix-premium.svg", price: 4.99, oldPrice: 5.99, discount: 17, stock: 11, featured: true, bestSeller: true, instant: true, kind: "subscription", platform: "TV", options: [{ ar: "شهر واحد", en: "1 month", price: 4.99 }, { ar: "3 أشهر", en: "3 months", price: 13.99 }] },
    { id: "p-spotify", slug: "spotify-premium", category: "subscriptions", title: { ar: "اشتراك Spotify Premium", en: "Spotify Premium" }, description: { ar: "استمتع بالموسيقى دون انقطاع.", en: "Enjoy your music without interruptions." }, image: "assets/products/spotify-premium.svg", price: 3.49, oldPrice: 4.25, discount: 18, stock: 14, featured: true, bestSeller: false, instant: true, kind: "subscription", platform: "Music", options: [{ ar: "شهر واحد", en: "1 month", price: 3.49 }, { ar: "3 أشهر", en: "3 months", price: 9.49 }] },
    { id: "p-telegram", slug: "telegram-premium", category: "chat", title: { ar: "Telegram Premium", en: "Telegram Premium" }, description: { ar: "ميزات إضافية وتجربة Telegram أوسع.", en: "Unlock more ways to use Telegram." }, image: "assets/products/telegram-premium.svg", price: 4.99, oldPrice: 5.99, discount: 17, stock: 10, featured: false, bestSeller: false, instant: true, kind: "subscription", platform: "Telegram", options: [{ ar: "شهر واحد", en: "1 month", price: 4.99 }, { ar: "سنة", en: "1 year", price: 34.99 }] },
    { id: "p-chatgpt", slug: "ai-plus", category: "ai", title: { ar: "خدمات الذكاء الاصطناعي", en: "AI services" }, description: { ar: "خدمات وأدوات رقمية لإبداعك وإنتاجيتك.", en: "Digital tools for creativity and productivity." }, image: "assets/products/ai-plus.svg", price: 7.99, oldPrice: 9.99, discount: 20, stock: 8, featured: true, bestSeller: false, instant: false, kind: "service", platform: "AI", options: [{ ar: "خطة شهرية", en: "Monthly plan", price: 7.99 }, { ar: "خطة سنوية", en: "Annual plan", price: 79.99 }] },
    { id: "p-googleplay", slug: "google-play-card", category: "cards", title: { ar: "بطاقة Google Play", en: "Google Play gift card" }, description: { ar: "رصيد رقمي للتطبيقات والألعاب.", en: "Digital credit for apps and games." }, image: "assets/products/google-play-card.svg", price: 5.79, oldPrice: 6.49, discount: 11, stock: 20, featured: false, bestSeller: true, instant: true, kind: "digital", platform: "Google Play", region: "US", options: [{ ar: "$5", en: "$5", price: 5.79 }, { ar: "$10", en: "$10", price: 11.49 }, { ar: "$25", en: "$25", price: 28.49 }] },
    { id: "p-mlbb", slug: "mobile-legends-diamonds", category: "games", title: { ar: "ألماس Mobile Legends", en: "Mobile Legends Diamonds" }, description: { ar: "اشحن الألماس وأكمل استعدادك للمباراة.", en: "Top up diamonds before your next match." }, image: "assets/products/mobile-legends-diamonds.svg", price: 1.29, oldPrice: 1.59, discount: 19, stock: 16, featured: false, bestSeller: true, instant: true, kind: "topup", platform: "Mobile", region: "Global", options: [{ ar: "86 ألماسة", en: "86 diamonds", price: 1.29 }, { ar: "172 ألماسة", en: "172 diamonds", price: 2.49 }, { ar: "257 ألماسة", en: "257 diamonds", price: 3.79 }] },
    { id: "p-xbox", slug: "xbox-game-pass", category: "subscriptions", title: { ar: "Xbox Game Pass", en: "Xbox Game Pass" }, description: { ar: "اختيار اشتراك لعشاق ألعاب Xbox.", en: "A subscription pick for Xbox players." }, image: "assets/products/xbox-game-pass.svg", price: 12.99, oldPrice: 14.99, discount: 13, stock: 9, featured: false, bestSeller: false, instant: true, kind: "subscription", platform: "Xbox", region: "Global", options: [{ ar: "شهر واحد", en: "1 month", price: 12.99 }, { ar: "3 أشهر", en: "3 months", price: 34.99 }] },
    { id: "p-itunes", slug: "apple-gift-card", category: "cards", title: { ar: "بطاقة Apple Gift Card", en: "Apple Gift Card" }, description: { ar: "رصيد لخدمات Apple والتطبيقات.", en: "Credit for Apple services and apps." }, image: "assets/products/apple-gift-card.svg", price: 5.99, oldPrice: 6.99, discount: 14, stock: 12, featured: false, bestSeller: false, instant: true, kind: "digital", platform: "Apple", region: "US", options: [{ ar: "$5", en: "$5", price: 5.99 }, { ar: "$10", en: "$10", price: 11.99 }, { ar: "$25", en: "$25", price: 29.49 }] },
    { id: "p-nintendo", slug: "nintendo-eshop-card", category: "cards", title: { ar: "بطاقة Nintendo eShop", en: "Nintendo eShop Card" }, description: { ar: "بطاقة رقمية لمتجر Nintendo eShop.", en: "Digital credit for Nintendo eShop." }, image: "assets/products/nintendo-eshop-card.svg", price: 11.49, oldPrice: 12.49, discount: 8, stock: 10, featured: false, bestSeller: false, instant: true, kind: "digital", platform: "Nintendo", region: "US", options: [{ ar: "$10 US", en: "$10 US", price: 11.49 }, { ar: "$20 US", en: "$20 US", price: 22.99 }] },
    { id: "p-balance", slug: "digital-balance", category: "wallet", title: { ar: "رصيد رقمي", en: "Digital balance" }, description: { ar: "اختر فئة الرصيد المناسبة لاستخدامك.", en: "Choose a balance amount for your account." }, image: "assets/products/digital-balance.svg", price: 5.49, oldPrice: 5.99, discount: 8, stock: 20, featured: false, bestSeller: false, instant: true, kind: "digital", platform: "Digital Wallet", options: [{ ar: "$5", en: "$5", price: 5.49 }, { ar: "$10", en: "$10", price: 10.99 }] },
    { id: "p-social", slug: "social-media-service", category: "social", title: { ar: "خدمة سوشيال ميديا", en: "Social media service" }, description: { ar: "اختر الخدمة الرقمية المناسبة لحسابك.", en: "Choose a digital service for your account." }, image: "assets/products/social-media-service.svg", price: 4.99, oldPrice: 5.99, discount: 17, stock: 10, featured: false, bestSeller: false, instant: false, kind: "service", platform: "Social", options: [{ ar: "باقة أساسية", en: "Starter package", price: 4.99 }, { ar: "باقة متقدمة", en: "Plus package", price: 9.99 }] },
    { id: "p-verify", slug: "account-service", category: "verification", title: { ar: "استشارة توثيق الحساب", en: "Account verification guidance" }, description: { ar: "إرشادات حول متطلبات وخطوات التوثيق.", en: "Guidance about verification requirements and steps." }, image: "assets/products/account-service.svg", price: 7.99, oldPrice: 9.99, discount: 20, stock: 6, featured: false, bestSeller: false, instant: false, kind: "service", platform: "Account service", options: [{ ar: "استشارة واحدة", en: "One consultation", price: 7.99 }] },
    { id: "p-vpn", slug: "vpn-subscription", category: "vpn", title: { ar: "اشتراك VPN", en: "VPN subscription" }, description: { ar: "اختر مدة الوصول المناسبة لك.", en: "Choose a subscription period." }, image: "assets/products/vpn-subscription.svg", price: 3.99, oldPrice: 4.99, discount: 20, stock: 12, featured: false, bestSeller: false, instant: true, kind: "subscription", platform: "VPN", options: [{ ar: "شهر واحد", en: "1 month", price: 3.99 }, { ar: "سنة", en: "1 year", price: 29.99 }] },
    { id: "p-design", slug: "design-tools", category: "design", title: { ar: "أدوات التصميم الرقمية", en: "Digital design tools" }, description: { ar: "خطة أدوات رقمية للمصممين وصناع المحتوى.", en: "Digital tools plan for designers and creators." }, image: "assets/products/design-tools.svg", price: 6.99, oldPrice: 8.49, discount: 18, stock: 9, featured: false, bestSeller: false, instant: true, kind: "subscription", platform: "Design", options: [{ ar: "شهر واحد", en: "1 month", price: 6.99 }, { ar: "سنة", en: "1 year", price: 59.99 }] },
    { id: "p-microsoft", slug: "microsoft-365", category: "microsoft", title: { ar: "خدمات Microsoft 365", en: "Microsoft 365 services" }, description: { ar: "خطة رقمية لخدمات الإنتاجية من Microsoft.", en: "A digital plan for Microsoft productivity services." }, image: "assets/products/microsoft-365.svg", price: 8.99, oldPrice: 9.99, discount: 10, stock: 8, featured: false, bestSeller: false, instant: true, kind: "subscription", platform: "Microsoft", options: [{ ar: "شهر واحد", en: "1 month", price: 8.99 }, { ar: "سنة", en: "1 year", price: 79.99 }] },
    { id: "p-pc", slug: "pc-tools", category: "pc", title: { ar: "أدوات الكمبيوتر الرقمية", en: "PC digital tools" }, description: { ar: "أدوات وخدمات رقمية للاستخدام على الكمبيوتر.", en: "Digital tools and services for your PC." }, image: "assets/products/pc-tools.svg", price: 5.99, oldPrice: 6.99, discount: 14, stock: 8, featured: false, bestSeller: false, instant: false, kind: "service", platform: "PC", options: [{ ar: "خطة أساسية", en: "Starter plan", price: 5.99 }, { ar: "خطة موسعة", en: "Plus plan", price: 11.99 }] }
  ];

  PRODUCTS.forEach((product) => { product.image = "assets/products/" + product.slug + ".svg"; });

  const INITIAL = { lang: "ar", cart: [], favorites: [], selectedOptions: {}, wallet: 0, orders: [], transactions: [], notifications: [{ id: 1, text: "مرحبًا بك في OTHMAN STORE", time: "الآن" }, { id: 2, text: "تصفح المنتجات والأقسام الجديدة", time: "اليوم" }], promo: "", promoRate: 0, user: null, pendingPurchase: null, tickets: [], checkoutStep: 1, checkoutData: {}, paymentMethod: "wallet" };
  const state = loadState();
  const icon = (name) => ({
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.7"/><path d="m16 16 5 5"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>',
    user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M4.5 20c.8-4 3.2-6 7.5-6s6.7 2 7.5 6"/></svg>',
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 4h2l2.4 11.1a2 2 0 0 0 2 1.6h8.7a2 2 0 0 0 2-1.6L22 8H6"/><circle cx="10" cy="20" r="1.3"/><circle cx="18" cy="20" r="1.3"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><path d="M20.8 8.9c0 5.2-8.8 11-8.8 11s-8.8-5.8-8.8-11a4.7 4.7 0 0 1 8.8-2.2 4.7 4.7 0 0 1 8.8 2.2Z"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/></svg>',
    grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.4"/><rect x="14" y="3" width="7" height="7" rx="1.4"/><rect x="3" y="14" width="7" height="7" rx="1.4"/><rect x="14" y="14" width="7" height="7" rx="1.4"/></svg>',
    wallet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 6.5h15a2 2 0 0 1 2 2V19H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12"/><path d="M16 12h5v4h-5a2 2 0 0 1 0-4Z"/><circle cx="16.5" cy="14" r=".5" fill="currentColor"/></svg>',
    "wallet-add": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 6h15a2 2 0 0 1 2 2v11H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12"/><path d="M16 13h5M18.5 10.5v5"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3 20 6v5.5c0 5.2-3.4 8-8 9.5-4.6-1.5-8-4.3-8-9.5V6Z"/><path d="m8.5 12 2.3 2.2 4.8-5"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>'
  }[name] || "");

  function loadState() {
    try {
      const stored = JSON.parse(localStorage.getItem("othman-store-state") || "{}");
      return { ...INITIAL, lang: stored.lang === "en" ? "en" : "ar", favorites: Array.isArray(stored.favorites) ? stored.favorites : [], selectedOptions: stored.selectedOptions && typeof stored.selectedOptions === "object" ? stored.selectedOptions : {} };
    } catch { return structuredClone(INITIAL); }
  }
  function save() { localStorage.setItem("othman-store-state", JSON.stringify({ lang: state.lang, favorites: state.favorites, selectedOptions: state.selectedOptions })); }
  function t(key) { return (COPY[state.lang] && COPY[state.lang][key]) || (WALLET_COPY[state.lang] && WALLET_COPY[state.lang][key]) || key; }
  function label(value) { return typeof value === "string" ? value : (value && value[state.lang]) || (value && value.ar) || ""; }
  function escapeHTML(value) { return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
  function money(value) { return new Intl.NumberFormat(state.lang === "ar" ? "en-US" : "en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(Number(value) || 0); }
  function setLang(lang) { state.lang = lang; save(); closeModal(); render(); }
  function navigate(path) { location.hash = path.startsWith("#") ? path : `#${path}`; }
  function toast(message) { const el = document.getElementById("toast"); el.textContent = message; el.classList.add("show"); clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600); }
  function productBySlug(slug) { return PRODUCTS.find((product) => product.slug === slug); }
  function categoryById(id) { return CATEGORIES.find((category) => category.id === id); }
  function getOption(product, index = 0) { return (product.options && product.options[index]) || { ar: "", en: "", price: product.price }; }
  function cartCount() { return state.cart.reduce((sum, item) => sum + item.qty, 0); }
  function cartSubtotal() { return state.cart.reduce((sum, item) => sum + item.price * item.qty, 0); }
  function discountAmount() { return cartSubtotal() * (state.promoRate || 0); }
  function cartTotal() { return Math.max(0, cartSubtotal() - discountAmount()); }
  function catName(category) { return category ? t(category.key) : t("products"); }
  function socialLink(labelText, short, href) { return href ? `<a href="${href}" target="_blank" rel="noopener noreferrer" aria-label="${labelText}">${short}</a>` : `<span class="unlinked" aria-label="${labelText}" title="${labelText}">${short}</span>`; }

  function brandMarkup() {
    return `<a class="brand" href="#/" aria-label="OTHMAN STORE"><img class="brand-mark" src="${ASSETS.mark}" alt="" width="49" height="49"><img class="brand-wordmark" src="${ASSETS.wordmark}" alt="OTHMAN STORE" width="130" height="40"></a>`;
  }
  function renderHeader() {
    const nav = [["/", "home"], ["/categories", "categories"], ["/products", "products"], ["/support", "support"], ["/about", "about"]];
    const href = location.hash.slice(1) || "/";
    document.getElementById("site-header").innerHTML = `<div class="site-header"><div class="header-inner">
      <button class="menu-button" data-action="open-menu" aria-label="${t("menu")}">${icon("menu")}</button>
      ${brandMarkup()}
      <nav class="main-nav" aria-label="${t("home")}">${nav.map(([route, key]) => `<a href="#${route}" ${href === route ? 'aria-current="page"' : ""}>${t(key)}</a>`).join("")}</nav>
      <div class="header-actions">
        <form id="header-search-form" class="header-search"><div class="search-box">${icon("search")}<input id="header-search-input" name="q" type="search" autocomplete="off" placeholder="${t("search")}" aria-label="${t("search")}"></div><div class="search-suggestions" id="header-suggestions" role="listbox"></div></form>
        <button class="icon-button mobile-search-button" data-action="focus-search" aria-label="${t("search")}">${icon("search")}</button>
        <button class="icon-button hide-mobile" data-action="notifications" aria-label="${t("notifications")}">${icon("bell")}<span class="count-badge">${state.notifications.length}</span></button>
        <a class="wallet-pill" href="#/wallet" aria-label="${t("wallet")}: ${money(state.wallet)}"><span class="wallet-add">+</span><span>${money(state.wallet)}</span></a>
        <a class="icon-button hide-mobile" href="#/account" aria-label="${t("account")}">${icon("user")}</a>
        <button class="lang-toggle" data-action="toggle-language" aria-label="${t("language")}">${t("language")}</button>
      </div>
    </div></div>`;
    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === "ar" ? "rtl" : "ltr";
  }

  function renderMobileNav() {
    const route = (location.hash.slice(1).split("?")[0] || "/").split("/")[1] || "";
    const links = [["/support", "protection", "shield"], ["/wallet", "wallet", "wallet"], ["/", "home", "home"], ["deposit", "addBalance", "wallet-add"], ["/products", "products", "grid"]];
    document.getElementById("mobile-nav").className = "mobile-bottom-nav";
    document.getElementById("mobile-nav").innerHTML = links.map(([url, key, ico]) => url === "deposit" ? `<button type="button" data-action="add-funds" aria-label="${t(key)}">${icon(ico)}<span>${t(key)}</span></button>` : `<a href="#${url}" class="${route === (url.slice(1) || "") ? "active" : ""}">${icon(ico)}<span>${t(key)}</span></a>`).join("");
  }

  function renderFooter() {
    const linkGroup = (title, links) => `<div class="footer-col"><h3>${title}</h3><div class="footer-links">${links.map(([key, url]) => `<a href="#${url}">${t(key)}</a>`).join("")}</div></div>`;
    document.getElementById("site-footer").innerHTML = `<div class="footer-inner"><div class="footer-main">
      <div class="footer-brand">${brandMarkup()}<p>${t("aboutText")}</p><div class="footer-slogan">YOUR DIGITAL WORLD</div><div class="social-links">${socialLink("WhatsApp", "WA", ASSETS.communityUrl)}${socialLink("Telegram", "TG", ASSETS.socialLinks.telegram)}${socialLink("Instagram", "IG", ASSETS.socialLinks.instagram)}${socialLink("Facebook", "FB", ASSETS.socialLinks.facebook)}${socialLink("TikTok", "TT", ASSETS.socialLinks.tiktok)}</div></div>
      ${linkGroup(t("home"), [["home", "/"], ["categories", "/categories"], ["products", "/products"]])}
      ${linkGroup(t("support"), [["support", "/support"], ["faq", "/support"], ["about", "/about"], ["orders", "/orders"]])}
      <div class="footer-col"><h3>${t("support")}</h3><div class="footer-links"><a href="#/support">${t("supportTitle")}</a><a href="tel:${escapeHTML(ASSETS.supportPhone || "+963992761983")}" dir="ltr">${escapeHTML(ASSETS.supportPhone || "+963992761983")}</a></div></div>
    </div><div class="footer-bottom"><span>© ${new Date().getFullYear()} OTHMAN STORE</span><span class="footer-slogan">YOUR DIGITAL WORLD</span><span><a href="#/privacy">${t("privacy")}</a> · <a href="#/terms">${t("terms")}</a></span></div></div>`;
  }

  function categoryCard(category) {
    return '<a href="#/category/' + escapeHTML(category.id) + '" class="category-card fade-up" aria-label="' + escapeHTML(catName(category)) + ' — OTHMAN STORE"><img src="' + escapeHTML(category.image) + '" alt="' + escapeHTML(catName(category)) + ' — OTHMAN STORE" loading="lazy" decoding="async"><div class="category-card-copy"><h3>' + escapeHTML(catName(category)) + '</h3></div></a>';
  }

  function productCard(product) {
    const favorite = state.favorites.includes(product.slug);
    const category = categoryById(product.category);
    return `<article class="product-card fade-up">
      <a class="product-image" href="#/product/${product.slug}" aria-label="${escapeHTML(t("details"))}: ${escapeHTML(label(product.title))}"><img src="${product.image}" alt="${escapeHTML(label(product.title))}" loading="lazy"><div class="product-badges">${product.instant ? `<span class="badge instant">${t("instant")}</span>` : ""}</div></a>
      <button class="favorite-button ${favorite ? "active" : ""}" data-action="favorite" data-slug="${product.slug}" aria-label="${favorite ? t("removeFavorite") : t("wishlist")}">${icon("heart")}</button>
      <div class="product-card-body"><div class="product-category">${escapeHTML(catName(category))}</div><h3 class="product-title">${escapeHTML(label(product.title))}</h3><p class="product-description">${escapeHTML(label(product.description))}</p>
        <div class="product-price-row"><span class="price">${money(getOption(product).price)}</span></div><div class="stock-line"><span class="stock-dot"></span>${t("available")}</div>
        <div class="card-actions"><a class="btn secondary small" href="#/product/${product.slug}">${t("details")}</a><button class="btn small" data-action="buy" data-slug="${product.slug}">${t("buyNow")}</button></div>
      </div></article>`;
  }

  function renderProductGrid(products, emptyText = t("noResults")) {
    if (!products.length) return `<div class="empty-state"><div class="empty-icon">⌕</div><h2>${emptyText}</h2><p>${t("trySearch")}</p><a class="btn secondary" href="#/categories">${t("browseCategories")}</a></div>`;
    return `<div class="product-grid">${products.map(productCard).join("")}</div>`;
  }

  function sectionHeading(title, subtitle, url = "/products") {
    return `<div class="section-heading"><div><h2>${title}</h2><p>${subtitle}</p></div><a class="text-link" href="#${url}">${t("seeAll")} <span aria-hidden="true">←</span></a></div>`;
  }

  function serviceCards() {
    return `<div class="service-grid"><div class="service-card"><span class="service-icon">↗</span><span><strong>${t("serviceDelivery")}</strong><small>${t("serviceDeliveryText")}</small></span></div><div class="service-card"><span class="service-icon">${icon("shield")}</span><span><strong>${t("serviceSecure")}</strong><small>${t("serviceSecureText")}</small></span></div><div class="service-card"><span class="service-icon">◌</span><span><strong>${t("serviceSupport")}</strong><small>${t("serviceSupportText")}</small></span></div><div class="service-card"><span class="service-icon">✦</span><span><strong>${t("serviceChoice")}</strong><small>${t("serviceChoiceText")}</small></span></div></div>`;
  }

  function faqMarkup() {
    return `<div class="faq-list"><details class="faq-item"><summary>${t("faq1")}</summary><p>${t("faq1a")}</p></details><details class="faq-item"><summary>${t("faq2")}</summary><p>${t("faq2a")}</p></details><details class="faq-item"><summary>${t("faq3")}</summary><p>${t("faq3a")}</p></details></div>`;
  }

  function searchMarkup(id = "search-input", initial = "") {
    return `<form id="search-form" class="search-wrap"><div class="search-box">${icon("search")}<input id="${id}" name="q" type="search" autocomplete="off" placeholder="${t("search")}" value="${escapeHTML(initial)}" aria-label="${t("search")}"><button class="btn small" type="submit">${t("searchResults")}</button></div><div class="search-suggestions" id="search-suggestions" role="listbox"></div></form>`;
  }

  function homeView() {
    const categories = CATEGORIES.slice(0, 6);
    const phone = ASSETS.supportPhone || "+963992761983";
    return '<div class="container"><section class="home-hero" aria-label="OTHMAN STORE"><img src="' + escapeHTML(ASSETS.hero) + '" alt="OTHMAN STORE — بطاقات الألعاب والخدمات الرقمية" loading="eager" fetchpriority="high" decoding="async"></section><section class="search-section home-search" aria-label="' + t("searchResults") + '">' + searchMarkup("search-input") + '</section><section class="home-categories" aria-label="' + t("categories") + '"><div class="category-grid">' + categories.map(categoryCard).join("") + '</div></section><section class="home-contact"><div class="home-contact-copy"><span class="eyebrow">' + t("support") + '</span><h2>' + t("supportTitle") + '</h2><p>' + t("supportText") + '</p></div><div class="home-contact-actions"><a class="contact-phone" href="tel:' + escapeHTML(phone) + '" dir="ltr">' + escapeHTML(phone) + '</a><button type="button" class="btn secondary small" data-action="copy-support">' + t("copy") + '</button><a class="btn small" href="' + escapeHTML(ASSETS.supportUrl || ("https://wa.me/" + phone.replace(/[^0-9]/g, ""))) + '" target="_blank" rel="noopener noreferrer">' + t("contactWhatsApp") + '</a></div><div class="store-credit"><img src="' + escapeHTML(ASSETS.mark) + '" alt="" width="26" height="26" loading="lazy" decoding="async"><span>' + (state.lang === "ar" ? 'من تصميم <strong>عثمان صناع</strong>' : 'Designed by <strong>Othman Sonaa</strong>') + '</span></div></section></div>';
  }

  function pageShell(content) { return '<div class="page-shell"><div class="container"><a class="back-button" href="#/" data-action="back" aria-label="' + t("back") + '"><span aria-hidden="true">' + (state.lang === "ar" ? "→" : "←") + '</span>' + t("back") + '</a>' + content + '</div></div>'; }

  function categoryListingView() {
    return pageShell('<div class="page-head"><div><span class="eyebrow">OTHMAN STORE</span><h1 class="page-title">' + t("categories") + '</h1></div></div><div class="category-grid category-grid-listing">' + CATEGORIES.map(categoryCard).join("") + '</div>');
  }

  function productsForCategory(id) {
    const category = categoryById(id);
    return PRODUCTS.filter((product) => product.category === id || (category && category.platform && product.platform === category.platform) || (id === "mobile" && product.kind === "topup"));
  }

  function categoryView(id) {
    const category = categoryById(id);
    if (!category) return notFoundView();
    const products = productsForCategory(id);
    return pageShell('<div class="breadcrumb"><a href="#/">' + t("home") + '</a><span>›</span><a href="#/categories">' + t("categories") + '</a><span>›</span><span>' + escapeHTML(catName(category)) + '</span></div><div class="page-head"><div><span class="eyebrow">' + t("categories") + '</span><h1 class="page-title">' + escapeHTML(catName(category)) + '</h1><p>' + products.length + ' ' + t("productCount") + '</p></div></div><div class="category-product-tools">' + searchMarkup("listing-search") + '<select class="chip" data-filter="sort" aria-label="' + t("sortBy") + '"><option value="popular">' + t("sortPopular") + '</option><option value="price-up">' + t("sortPriceLow") + '</option><option value="price-down">' + t("sortPriceHigh") + '</option></select></div><div id="filter-results">' + renderProductGrid(products) + '</div>');
  }

  function productListingView() {
    return pageShell('<div class="page-head"><div><span class="eyebrow">OTHMAN STORE</span><h1 class="page-title">' + t("products") + '</h1><p>' + PRODUCTS.length + ' ' + t("productCount") + '</p></div></div><div class="category-product-tools">' + searchMarkup("listing-search") + '<select class="chip" data-filter="sort" aria-label="' + t("sortBy") + '"><option value="popular">' + t("sortPopular") + '</option><option value="price-up">' + t("sortPriceLow") + '</option><option value="price-down">' + t("sortPriceHigh") + '</option></select></div><div id="filter-results">' + renderProductGrid(PRODUCTS.slice()) + '</div>');
  }

  function productDetailView(slug) {
    const product = productBySlug(slug);
    if (!product) return notFoundView();
    const category = categoryById(product.category), options = product.options && product.options.length ? product.options : [{ ar: "", en: "", price: product.price }];
    const selected = Math.max(0, Math.min(options.length - 1, Number(state.selectedOptions && state.selectedOptions[slug]) || 0));
    const optionMarkup = options.length > 1 ? '<div class="field full"><label>' + t("chooseOption") + '</label><div class="option-grid">' + options.map((option, index) => '<button class="option-button ' + (index === selected ? "active" : "") + '" type="button" data-action="option" data-slug="' + escapeHTML(slug) + '" data-index="' + index + '"><strong>' + escapeHTML(label(option)) + '</strong><small>' + money(option.price) + '</small></button>').join("") + '</div></div>' : '';
    const playerFields = product.kind === "topup" ? '<div class="field"><label for="purchase-player-id">' + t("playerId") + ' *</label><input id="purchase-player-id" name="playerId" required inputmode="text" autocomplete="off" placeholder="' + t("enterPlayerId") + '"></div><div class="field"><label for="purchase-server">' + t("server") + '</label><input id="purchase-server" name="server" value="' + escapeHTML(product.region || "") + '" autocomplete="off"></div>' : '';
    return pageShell('<div class="breadcrumb"><a href="#/">' + t("home") + '</a><span>›</span><a href="#/category/' + escapeHTML(product.category) + '">' + escapeHTML(catName(category)) + '</a><span>›</span><span>' + escapeHTML(label(product.title)) + '</span></div><div class="detail-layout"><div class="detail-image"><img src="' + escapeHTML(product.image) + '" alt="' + escapeHTML(label(product.title)) + '"></div><section class="detail-info"><span class="eyebrow">' + escapeHTML(catName(category)) + '</span><h1>' + escapeHTML(label(product.title)) + '</h1><p class="detail-description">' + escapeHTML(label(product.description)) + '</p><div class="detail-price"><span class="price">' + money(getOption(product, selected).price) + '</span>' + (product.oldPrice ? '<span class="old-price">' + money(product.oldPrice) + '</span>' : '') + '</div><form id="product-form" data-slug="' + escapeHTML(slug) + '" class="form-card product-purchase-form"><div class="form-grid">' + optionMarkup + playerFields + '<div class="field"><label for="product-qty">' + t("quantity") + '</label><input id="product-qty" name="qty" type="number" min="1" max="10" step="1" value="1" required></div><div class="field full"><button class="btn full" type="submit" name="intent" value="buy">' + t("buyNow") + ' · ' + money(getOption(product, selected).price) + '</button><small class="form-note">' + (state.user ? t("paymentWalletText") + ' ' + money(state.wallet) : t("purchaseLoginNote")) + '</small></div></div></form></section></div>');
  }

  function searchResultsView(query) {
    const q = (query || "").trim().toLowerCase();
    let list = searchProducts(q);
    return pageShell(`<div class="page-head"><div><span class="eyebrow">${t("searchResults")}</span><h1 class="page-title">${q ? `${t("searchResults")}: “${escapeHTML(query)}”` : t("products")}</h1><p>${list.length} ${t("productCount")}</p></div></div>${searchMarkup("results-search", query || "")}<section class="section"><div class="split-layout"><aside class="panel-card"><h2>${t("categories")}</h2><div class="footer-links">${CATEGORIES.map((c) => `<a href="#/category/${c.id}">${t(c.key)}</a>`).join("")}</div><div class="field" style="margin-top:18px"><label for="max-price">${t("maxPrice")}</label><input id="max-price" type="number" min="0" placeholder="100" data-filter="max-price"></div><button class="btn secondary small" data-action="clear-filters" style="margin-top:12px">${t("clear")}</button></aside><div><div class="inline-row" style="margin-bottom:14px"><span>${t("sortBy")}</span><select class="chip" data-filter="sort"><option value="popular">${t("sortPopular")}</option><option value="newest">${t("sortNewest")}</option><option value="price-up">${t("sortPriceLow")}</option><option value="price-down">${t("sortPriceHigh")}</option><option value="discount">${t("sortDiscount")}</option></select></div><div id="filter-results">${renderProductGrid(list)}</div></div></div></section>`);
  }

  function searchProducts(q) {
    if (!q) return PRODUCTS.slice();
    return PRODUCTS.filter((p) => {
      const cat = categoryById(p.category);
      const haystack = [label(p.title), p.title.ar, p.title.en, label(p.description), p.category, cat && t(cat.key), p.platform, p.region].join(" ").toLowerCase();
      return haystack.includes(q);
    });
  }

  function cartView() {
    if (!state.cart.length) return pageShell(`<div class="breadcrumb"><a href="#/">${t("home")}</a><span>›</span><span>${t("cartTitle")}</span></div><div class="empty-state"><div class="empty-icon">${icon("cart")}</div><h2>${t("emptyCart")}</h2><p>${t("emptyCartText")}</p><a class="btn" href="#/products">${t("continueShopping")}</a></div>`);
    const rows = state.cart.map((item) => { const product = productBySlug(item.slug); return `<article class="cart-item"><img src="${product ? product.image : ASSETS.giftCards}" alt="${escapeHTML(product ? label(product.title) : item.slug)}"><div><h3>${escapeHTML(product ? label(product.title) : item.slug)}</h3><p>${escapeHTML(item.option || "")} ${item.details && item.details.playerId ? `· ${t("playerId")}: ${escapeHTML(item.details.playerId)}` : ""}</p><div class="quantity-control"><button data-action="cart-qty" data-key="${escapeHTML(item.key)}" data-change="-1" aria-label="−">−</button><input value="${item.qty}" readonly aria-label="${t("quantity")}"><button data-action="cart-qty" data-key="${escapeHTML(item.key)}" data-change="1" aria-label="+">+</button></div></div><div class="cart-item-end"><span class="price">${money(item.price * item.qty)}</span><button class="text-link" data-action="remove-cart" data-key="${escapeHTML(item.key)}">${t("remove")}</button><button class="text-link" data-action="save-cart" data-key="${escapeHTML(item.key)}">${t("saveLater")}</button></div></article>`; }).join("");
    return pageShell(`<div class="breadcrumb"><a href="#/">${t("home")}</a><span>›</span><span>${t("cartTitle")}</span></div><div class="page-head"><div><span class="eyebrow">${t("cart")}</span><h1 class="page-title">${t("cartTitle")}</h1><p>${cartCount()} ${t("productCount")}</p></div><a class="btn secondary" href="#/products">${t("continueShopping")}</a></div><div class="split-layout"><div class="cart-list">${rows}</div><aside class="panel-card summary-card"><h2>${t("orderSummary")}</h2><div class="promo-row"><input id="promo-code" placeholder="${t("promo")}" value="${escapeHTML(state.promo)}"><button class="btn secondary small" data-action="apply-promo">${t("apply")}</button></div><div class="summary-row"><span>${t("subtotal")}</span><strong>${money(cartSubtotal())}</strong></div>${state.promoRate ? `<div class="summary-row"><span>${t("discount")}</span><strong>−${money(discountAmount())}</strong></div>` : ""}<div class="summary-row total"><span>${t("total")}</span><strong>${money(cartTotal())}</strong></div><button class="btn full" data-action="checkout">${t("checkout")}</button><p class="form-note">${t("noBackend")}</p></aside></div>`);
  }

  function checkoutView() {
    if (!state.cart.length) { navigate("/cart"); return ""; }
    const step = state.checkoutStep || 1;
    const steps = ["customerInfo", "serviceDetails", "payment", "confirmation"];
    const progress = `<div class="checkout-steps">${steps.map((key, i) => `<div class="checkout-step ${step === i + 1 ? "active" : step > i + 1 ? "done" : ""}"><span>${step > i + 1 ? "✓" : i + 1}</span>${t(key)}</div>`).join("")}</div>`;
    let formContent = "";
    if (step === 1) formContent = `<h2>${t("customerInfo")}</h2><div class="form-grid"><div class="field full"><label for="checkout-name">${t("fullName")} *</label><input id="checkout-name" name="name" required value="${escapeHTML(state.checkoutData.name || (state.user && state.user.name) || "")}"></div><div class="field"><label for="checkout-email">${t("email")} *</label><input id="checkout-email" name="email" type="email" required value="${escapeHTML(state.checkoutData.email || (state.user && state.user.email) || "")}"></div><div class="field"><label for="checkout-phone">${t("phone")} *</label><input id="checkout-phone" name="phone" type="tel" required value="${escapeHTML(state.checkoutData.phone || "")}"></div></div>`;
    if (step === 2) formContent = `<h2>${t("serviceDetails")}</h2><p class="form-note">${t("faqAnswerOrder")}</p><div class="cart-list" style="margin-top:16px">${state.cart.map((item) => `<div class="cart-item"><img src="${(productBySlug(item.slug) || {}).image || ASSETS.giftCards}" alt=""><div><h3>${escapeHTML(label((productBySlug(item.slug) || {}).title || item.slug))}</h3><p>${escapeHTML(item.option || "")} · ${t("quantity")}: ${item.qty}</p><p>${item.details && item.details.playerId ? `${t("playerId")}: ${escapeHTML(item.details.playerId)} · ${t("server")}: ${escapeHTML(item.details.server || "")}` : t("instant")}</p></div><span class="price">${money(item.price * item.qty)}</span></div>`).join("")}</div>`;
    if (step === 3) {
      const walletChoice = state.user
        ? '<label class="payment-option"><input type="radio" name="payment" value="wallet" ' + (state.paymentMethod === "wallet" ? "checked" : "") + '><span><strong>' + t("paymentWallet") + '</strong><small>' + t("paymentWalletText") + ' ' + money(state.wallet) + '</small></span></label>'
        : '<p class="form-note"><a class="text-link" href="#/login">' + t("signIn") + '</a> ' + t("paymentWalletText") + '</p>';
      const cashChoice = '<label class="payment-option"><input type="radio" name="payment" value="shamcash" ' + (state.paymentMethod !== "wallet" ? "checked" : "") + '><span><strong>' + t("paymentTransfer") + '</strong><small>' + t("paymentTransferText") + '</small><b class="shamcash-number" dir="ltr">' + escapeHTML(SHAM_CASH.walletNumber) + '</b><button class="text-link" type="button" data-action="copy-shamcash">' + t("shamCashCopy") + '</button></span></label>';
      const walletNote = state.user ? '<div class="wallet-checkout-note ' + (state.wallet >= cartTotal() ? "is-ready" : "is-short") + '"><div><strong>' + (state.wallet >= cartTotal() ? t("walletPayReady") : t("walletInsufficient")) + '</strong><small>' + t("currentBalance") + ': ' + money(state.wallet) + '</small></div>' + (state.wallet < cartTotal() ? '<button class="text-link" type="button" data-action="add-funds">' + t("addBalance") + '</button>' : "") + '</div>' : "";
      formContent = '<h2>' + t("payment") + '</h2><div class="payment-options" style="margin-top:14px">' + walletChoice + cashChoice + '</div>' + walletNote;
    }
    if (step === 4) formContent = `<h2>${t("confirmation")}</h2><p class="form-note">${escapeHTML(state.checkoutData.name || "")} · ${escapeHTML(state.checkoutData.email || "")}</p><div class="summary-row"><span>${t("orderItems")}</span><strong>${cartCount()}</strong></div><div class="summary-row"><span>${t("payment")}</span><strong>${t(state.paymentMethod === "wallet" ? "paymentWallet" : state.paymentMethod === "gateway" ? "paymentGateway" : "paymentTransfer")}</strong></div><div class="summary-row total"><span>${t("total")}</span><strong>${money(cartTotal())}</strong></div><p class="form-note">${t("noBackend")}</p>`;
    const aside = `<aside class="panel-card summary-card"><h2>${t("orderSummary")}</h2>${state.cart.slice(0, 4).map((item) => `<div class="summary-row"><span>${escapeHTML(label((productBySlug(item.slug) || {}).title || item.slug))} × ${item.qty}</span><strong>${money(item.price * item.qty)}</strong></div>`).join("")}<div class="summary-row"><span>${t("subtotal")}</span><strong>${money(cartSubtotal())}</strong></div>${state.promoRate ? `<div class="summary-row"><span>${t("discount")}</span><strong>−${money(discountAmount())}</strong></div>` : ""}<div class="summary-row total"><span>${t("total")}</span><strong>${money(cartTotal())}</strong></div></aside>`;
    return pageShell(`<div class="page-head"><div><span class="eyebrow">${t("checkoutTitle")}</span><h1 class="page-title">${t("checkoutTitle")}</h1><p>${t("noBackend")}</p></div></div>${progress}<div class="split-layout"><form id="checkout-form" class="form-card">${formContent}<div class="inline-row" style="margin-top:20px"><button class="btn secondary" type="button" data-action="checkout-back" ${step === 1 ? "disabled" : ""}>${t("back")}</button>${step < 4 ? `<button class="btn" type="submit">${t("next")}</button>` : `<button class="btn" type="button" data-action="place-order">${t("confirmOrder")}</button>`}</div></form>${aside}</div>`);
  }

  function orderCard(order) {
    return `<article class="order-card"><div class="order-head"><div><strong>${t("orderNo")} #${escapeHTML(order.id)}</strong><p>${escapeHTML(order.date || (order.createdAt ? new Date(order.createdAt).toLocaleDateString() : ""))} · ${money(order.total)}</p></div><span class="status-pill">${t(order.status || "pending")}</span></div><p>${t("orderItems")}: ${order.items.map((item) => `${escapeHTML(label((productBySlug(item.slug) || {}).title || item.slug))} × ${item.qty}`).join(", ")}</p><p>${t("paymentStatus")}: ${t(order.paymentStatus || "pending")} · ${t("deliveryStatus")}: ${t(order.deliveryStatus || "pending")}</p><div class="inline-row"><a class="text-link" href="${ASSETS.supportUrl}" target="_blank" rel="noopener noreferrer">${t("support")}</a><button class="text-link" data-action="invoice" data-id="${escapeHTML(order.id)}">${t("invoice")}</button></div></article>`;
  }

  function ordersView() {
    return pageShell(`<div class="page-head"><div><span class="eyebrow">${t("account")}</span><h1 class="page-title">${t("orderHistory")}</h1><p>${state.orders.length} ${t("orders")}</p></div></div>${state.orders.length ? `<div class="order-list">${state.orders.map(orderCard).join("")}</div>` : `<div class="empty-state"><div class="empty-icon">▤</div><h2>${t("noOrders")}</h2><p>${t("noOrdersText")}</p><a class="btn" href="#/products">${t("shopNow")}</a></div>`}`);
  }

  function walletView() {
    const transactions = state.transactions.length ? state.transactions.map((item) => `<div class="transaction"><span>${escapeHTML(item.title)}<small>${escapeHTML(item.date)} · ${escapeHTML(item.status)}${item.reference ? ` · ${t("shamCashReference")}: ${escapeHTML(item.reference)}` : ""}${item.receiptName ? ` · ${escapeHTML(item.receiptName)}` : ""}</small></span><strong class="amount ${item.amount != null && Number(item.amount) < 0 ? "debit" : "credit"}">${item.amount == null ? t("pending") : `${Number(item.amount) > 0 ? "+" : ""}${money(item.amount)}`}</strong></div>`).join("") : `<p class="form-note">${t("noTransactions")}</p>`;
    const walletNumber = SHAM_CASH.walletNumber ? `<strong class="shamcash-number" dir="ltr">${escapeHTML(SHAM_CASH.walletNumber)}</strong><button class="text-link" data-action="copy-shamcash">${t("shamCashCopy")}</button>` : `<strong class="shamcash-number unconfigured">${t("shamCashSetup")}</strong>`;
    return pageShell(`<div class="page-head"><div><span class="eyebrow">${t("account")}</span><h1 class="page-title">${t("walletTitle")}</h1><p>${t("demoDeposit")}</p></div></div><div class="split-layout"><div><div class="balance-card"><small>${t("currentBalance")}</small><strong>${money(state.wallet)}</strong><button class="btn" data-action="add-funds">＋ ${t("addBalance")}</button></div><section class="section"><div class="section-heading"><div><h2>${t("transactions")}</h2></div></div><div class="panel-card wallet-transactions">${transactions}</div></section></div><aside class="panel-card shamcash-panel"><span class="eyebrow">${t("shamCashTitle")}</span><h2>${t("shamCashSubtitle")}</h2><div class="shamcash-recipient"><span class="shamcash-mark">SC</span><div><small>${t("shamCashRecipient")}</small><strong>${escapeHTML(SHAM_CASH.recipientName)}</strong></div></div><div class="shamcash-destination"><small>${t("shamCashNumber")}</small>${walletNumber}</div><ol class="shamcash-steps"><li>${t("shamCashStep1")}</li><li>${t("shamCashStep2")}</li><li>${t("shamCashStep3")}</li></ol><button class="btn full" data-action="add-funds">${t("addBalance")}</button><p class="form-note">${t("shamCashReceiptNote")}</p></aside></div>`);
  }

  function accountView() {
    const user = state.user;
    const name = user ? escapeHTML(user.name) : t("accountTitle");
    const email = user ? escapeHTML(user.email) : "";
    const initial = user ? escapeHTML(Array.from(user.name.trim())[0] || "O") : "O";
    const ordersCount = state.orders.length;
    const favoritesCount = state.favorites.length;
    return pageShell(`<section class="account-hero"><div class="account-avatar">${initial}</div><div class="account-intro"><span class="eyebrow">OTHMAN STORE</span><h1>${name}</h1><p>${user ? email : t("signInText")}</p></div>${user ? `<button class="btn secondary" data-action="logout">${t("signOut")}</button>` : `<a class="btn" href="#/login">${t("signIn")}</a>`}</section><section class="account-stats"><a class="account-stat" href="#/wallet"><span>${t("currentBalance")}</span><strong>${money(state.wallet)}</strong></a><a class="account-stat" href="#/orders"><span>${t("orders")}</span><strong>${ordersCount}</strong></a><a class="account-stat" href="#/favorites"><span>${t("favorites")}</span><strong>${favoritesCount}</strong></a></section><section class="account-content"><div class="account-shortcuts"><a class="account-shortcut" href="#/orders"><span class="shortcut-icon">▤</span><span><strong>${t("orderHistory")}</strong><small>${t("faqAnswerOrder")}</small></span><b aria-hidden="true">←</b></a><a class="account-shortcut" href="#/wallet"><span class="shortcut-icon">◈</span><span><strong>${t("walletTitle")}</strong><small>${t("currentBalance")}: ${money(state.wallet)}</small></span><b aria-hidden="true">←</b></a><a class="account-shortcut" href="#/favorites"><span class="shortcut-icon">♡</span><span><strong>${t("favoritesTitle")}</strong><small>${favoritesCount} ${t("productCount")}</small></span><b aria-hidden="true">←</b></a><a class="account-shortcut" href="#/support"><span class="shortcut-icon">⌕</span><span><strong>${t("supportTitle")}</strong><small>${t("supportText")}</small></span><b aria-hidden="true">←</b></a></div><div class="panel-card account-profile"><div class="account-profile-heading"><div><span class="eyebrow">${t("accountTitle")}</span><h2>${t("profile")}</h2></div><span class="profile-status">${user ? t("authSuccess") : t("signIn")}</span></div>${user ? `<div class="profile-row"><span>${t("fullName")}</span><strong>${escapeHTML(user.name)}</strong></div><div class="profile-row"><span>${t("email")}</span><strong dir="ltr">${email}</strong></div><div class="profile-row"><span>${t("phone")}</span><strong dir="ltr">${escapeHTML(user.phone || "—")}</strong></div>` : `<p>${t("signInText")}</p><a class="btn full" href="#/register">${t("signUp")}</a>`}</div></section>`);
  }

  function favoritesView() {
    const list = PRODUCTS.filter((p) => state.favorites.includes(p.slug));
    return pageShell(`<div class="page-head"><div><span class="eyebrow">${t("account")}</span><h1 class="page-title">${t("favoritesTitle")}</h1><p>${list.length} ${t("productCount")}</p></div></div>${list.length ? renderProductGrid(list) : `<div class="empty-state"><div class="empty-icon">♡</div><h2>${t("emptyFavorites")}</h2><p>${t("trySearch")}</p><a class="btn" href="#/products">${t("shopNow")}</a></div>`}`);
  }

  function supportView() {
    const phone = ASSETS.supportPhone || "+963992761983";
    return pageShell('<div class="page-head"><div><span class="eyebrow">OTHMAN STORE</span><h1 class="page-title">' + t("supportTitle") + '</h1><p>' + t("supportText") + '</p></div></div><div class="split-layout"><div class="panel-card"><h2>' + t("createTicket") + '</h2><form id="ticket-form" class="form-grid" style="margin-top:15px"><div class="field full"><label for="ticket-subject">' + t("subject") + '</label><input id="ticket-subject" name="subject" required></div><div class="field full"><label for="ticket-message">' + t("message") + '</label><textarea id="ticket-message" name="message" required placeholder="' + t("message") + '"></textarea></div><div class="field"><label for="ticket-name">' + t("fullName") + '</label><input id="ticket-name" name="name" autocomplete="name"></div><div class="field"><label for="ticket-email">' + t("email") + '</label><input id="ticket-email" name="email" type="email"></div><div class="field full"><label for="ticket-phone">' + t("phone") + '</label><input id="ticket-phone" name="phone" type="tel"></div><div class="field full"><button class="btn" type="submit">' + t("createTicket") + '</button></div></form></div><div class="panel-card"><h2>' + t("support") + '</h2><p>' + t("supportHours") + '</p><p class="support-phone" dir="ltr">' + escapeHTML(phone) + '</p><div class="category-chips"><a class="btn" href="' + escapeHTML(ASSETS.supportUrl) + '" target="_blank" rel="noopener noreferrer">' + t("contactWhatsApp") + ' ↗</a><a class="btn secondary" href="tel:' + escapeHTML(phone) + '">' + t("phone") + '</a><button class="btn secondary" type="button" data-action="copy-support">' + t("copy") + ' ' + t("phone") + '</button></div><p class="form-note">' + t("faq") + '</p>' + faqMarkup() + '</div></div>');
  }

  function offersView() {
    const deals = PRODUCTS.filter((p) => p.discount > 0).sort((a, b) => b.discount - a.discount);
    return pageShell(`<div class="page-head"><div><span class="eyebrow">${t("offers")}</span><h1 class="page-title">${t("offerTitle")}</h1><p>${t("offerText")}</p></div></div><div class="deal-panel"><div class="deal-copy"><span class="eyebrow">OTHMAN STORE</span><h2>${t("browseDeals")}</h2><p>${t("bestSellersText")}</p><a class="btn" href="#/products">${t("shopNow")}</a></div><div class="rail">${deals.slice(0, 3).map(productCard).join("")}</div></div><section class="section">${renderProductGrid(deals)}</section>`);
  }

  function loginView(register = false) {
    const arabic = state.lang === "ar";
    const heading = register ? (arabic ? "أنشئ حسابك" : "Create your account") : (arabic ? "أهلًا بعودتك" : "Welcome back");
    const subheading = register ? (arabic ? "سجّل الآن لتتابع طلباتك ومحفظتك في مكان واحد." : "Create an account to keep your orders and wallet together.") : (arabic ? "سجّل الدخول لمتابعة طلباتك والشراء من محفظتك." : "Sign in to track orders and buy with your wallet.");
    const nameField = register ? `<div class="field full"><label for="auth-name">${t("fullName")}</label><input id="auth-name" name="name" required minlength="2" autocomplete="name" placeholder="${arabic ? "الاسم كما يظهر في الطلب" : "Your full name"}"></div><div class="field full"><label for="auth-phone">${t("phone")}</label><input id="auth-phone" name="phone" required type="tel" minlength="6" autocomplete="tel" placeholder="+963..."></div>` : "";
    const passwordField = (id, fieldLabel, autocomplete, placeholder = "") => `<div class="field full"><label for="${id}">${fieldLabel}</label><div class="auth-password-wrap"><input id="${id}" name="${id === "auth-confirm" ? "confirm" : "password"}" required type="password" minlength="10" autocomplete="${autocomplete}" ${placeholder ? `placeholder="${placeholder}"` : ""}><button class="auth-password-toggle" type="button" data-action="toggle-password" data-password-target="${id}" aria-label="${arabic ? "إظهار كلمة المرور" : "Show password"}" aria-pressed="false">${arabic ? "إظهار" : "Show"}</button></div></div>`;
    const password = passwordField("auth-password", t("password"), register ? "new-password" : "current-password", arabic ? "10 أحرف على الأقل" : "At least 10 characters");
    const confirmField = register ? passwordField("auth-confirm", t("confirmPassword"), "new-password") : `<div class="auth-options field full"><label class="checkbox-row"><input type="checkbox" name="remember"> ${t("remember")}</label></div>`;
    return `<section class="auth-screen"><div class="auth-art"><img src="${escapeHTML(ASSETS.hero)}" alt="OTHMAN STORE"><div class="auth-art-shade"></div><div class="auth-art-caption"><span class="auth-live-dot"></span>${arabic ? "عالمك الرقمي في مكان واحد" : "Your digital world in one place"}</div></div><div class="auth-shell fade-up"><a class="auth-back back-button" href="#/" data-action="back"><span aria-hidden="true">${arabic ? "→" : "←"}</span>${t("back")}</a>${brandMarkup()}<div class="auth-heading"><span class="eyebrow">OTHMAN STORE</span><h1>${heading}</h1><p>${subheading}</p></div><form id="auth-form" class="form-card"><div class="form-grid">${nameField}<div class="field full"><label for="auth-email">${t("email")}</label><input id="auth-email" name="email" required type="email" autocomplete="email" placeholder="name@example.com"></div>${password}${confirmField}<div class="field full"><button class="btn full auth-submit" type="submit"><span class="auth-spinner" aria-hidden="true"></span><span class="auth-submit-label">${register ? t("signUp") : t("signIn")}</span><span class="auth-submit-arrow" aria-hidden="true">←</span></button></div></div></form><p class="auth-switch">${register ? t("haveAccount") : t("noAccount")} <a class="text-link" href="#/${register ? "login" : "register"}">${register ? t("signIn") : t("signUp")}</a></p></div></section>`;
  }

  function staticView(which) {
    const title = which === "about" ? t("aboutTitle") : which === "privacy" ? t("privacy") : t("terms");
    const text = which === "about" ? t("aboutText") : t("noBackend");
    return pageShell(`<div class="page-head"><div><span class="eyebrow">OTHMAN STORE</span><h1 class="page-title">${title}</h1><p>${text}</p></div></div><div class="panel-card"><p>${text}</p><a class="btn secondary" href="#/support">${t("support")}</a></div>`);
  }
  function notFoundView() { return pageShell(`<div class="empty-state"><div class="empty-icon">⌁</div><h2>${t("notFound")}</h2><a class="btn" href="#/">${t("goHome")}</a></div>`); }

  function render() {
    renderHeader(); renderMobileNav(); renderFooter();
    const raw = location.hash.slice(1) || "/";
    const [path, query] = raw.split("?");
    const params = new URLSearchParams(query || "");
    const parts = path.split("/").filter(Boolean);
    let content;
    if (!parts.length) content = homeView();
    else if (parts[0] === "categories") content = categoryListingView();
    else if (parts[0] === "category") content = categoryView(parts[1]);
    else if (parts[0] === "products") content = productListingView();
    else if (parts[0] === "product") content = productDetailView(parts[1]);
    else if (parts[0] === "search") content = searchResultsView(params.get("q") || "");
    else if (parts[0] === "cart") { location.hash = "#/products"; return; }
    else if (parts[0] === "checkout") { location.hash = "#/products"; return; }
    else if (parts[0] === "wallet") content = walletView();
    else if (parts[0] === "orders") content = ordersView();
    else if (parts[0] === "account") content = accountView();
    else if (parts[0] === "favorites") content = favoritesView();
    else if (parts[0] === "support") content = supportView();
    else if (parts[0] === "offers") { location.hash = "#/products"; return; }
    else if (parts[0] === "login") content = loginView(false);
    else if (parts[0] === "register") content = loginView(true);
    else if (["about", "privacy", "terms"].includes(parts[0])) content = staticView(parts[0]);
    else content = notFoundView();
    document.getElementById("main-content").innerHTML = content;
    document.title = `OTHMAN STORE | ${parts.length ? t(parts[0] === "category" ? (categoryById(parts[1]) || {}).key || "categories" : parts[0] === "product" ? "products" : parts[0]) : t("home")}`;
    document.body.classList.toggle("is-home", !parts.length);
  }

  function addToCart(product, optionIndex = 0, qty = 1, details = {}) {
    const option = getOption(product, optionIndex);
    const key = `${product.slug}:${label(option) || optionIndex}:${details.playerId || ""}`;
    const existing = state.cart.find((item) => item.key === key);
    if (existing) existing.qty = Math.min(10, existing.qty + qty);
    else state.cart.push({ key, slug: product.slug, option: label(option), price: option.price, qty, details });
    save();
  }

  function queuePurchase(product, optionIndex = 0, qty = 1, details = {}) {
    state.pendingPurchase = { slug: product.slug, optionIndex, quantity: qty, details };
    save();
    navigate("/register");
    toast(t("purchaseLoginNote"));
  }

  async function submitPurchase(purchase, button) {
    const product = productBySlug(purchase.slug);
    if (!product) { toast(t("notFound")); return; }
    if (!state.user) { queuePurchase(product, purchase.optionIndex, purchase.quantity, purchase.details || {}); return; }
    if (!window.StoreAPI) { toast(t("noBackend")); return; }
    if (button) { button.disabled = true; button.dataset.busy = "true"; }
    try {
      const response = await window.StoreAPI.order({
        customer: state.checkoutData,
        items: [{ productId: product.id, slug: product.slug, optionIndex: Number(purchase.optionIndex) || 0, quantity: Math.max(1, Math.min(10, Number(purchase.quantity) || 1)), playerId: purchase.details && purchase.details.playerId || "", server: purchase.details && purchase.details.server || "", username: purchase.details && purchase.details.username || "", accountEmail: purchase.details && purchase.details.accountEmail || "" }],
        paymentMethod: "wallet"
      });
      const saved = response.order;
      const order = { id: saved.id, date: new Date(saved.createdAt).toLocaleDateString(), createdAt: saved.createdAt, total: saved.total, items: saved.items.map((item) => ({ slug: item.slug, qty: item.quantity, title: item.title })), status: saved.status, paymentMethod: saved.paymentMethod, paymentStatus: saved.paymentStatus, deliveryStatus: saved.deliveryStatus };
      state.orders.unshift(order);
      state.wallet = Number(response.balance || 0);
      state.transactions.unshift({ id: saved.id, type: "purchase", title: t("walletPurchase"), amount: -saved.total, date: order.date, status: t("completed") });
      state.pendingPurchase = null;
      state.notifications.unshift({ id: Date.now(), text: t("orderCreated") + " · " + saved.id, time: new Date().toLocaleTimeString() });
      save(); closeModal(); render(); navigate("/orders"); toast(t("orderCreated") + " · " + saved.id);
    } catch (error) {
      if (error.status === 401) { queuePurchase(product, purchase.optionIndex, purchase.quantity, purchase.details || {}); }
      else if (error.status === 409 && /رصيد|balance|wallet/i.test(error.message)) { toast(error.message); navigate("/wallet"); }
      else toast(error.message);
    } finally { if (button) { button.disabled = false; delete button.dataset.busy; } }
  }

  function beginPurchase(product, optionIndex = 0, qty = 1, details = {}, button) {
    const purchase = { slug: product.slug, optionIndex, quantity: qty, details };
    if (!state.user) { queuePurchase(product, optionIndex, qty, details); return; }
    submitPurchase(purchase, button);
  }

  function toggleFavorite(slug) {
    if (state.favorites.includes(slug)) { state.favorites = state.favorites.filter((item) => item !== slug); toast(t("removeFavorite")); }
    else { state.favorites.push(slug); toast(t("wishlist")); }
    save(); render();
  }

  function parseRoute() { const raw = location.hash.slice(1) || "/"; return raw.split("?")[0]; }
  function openMenu() {
    if (document.querySelector(".mobile-menu-panel")) return;
    const accountBlock = state.user ? (() => {
      const displayName = state.user.name || state.user.email || t("account");
      const initial = String(displayName).trim().charAt(0) || "•";
      return `<section class="menu-account-card menu-account-signed" aria-label="${t("account")}">
        <div class="menu-account-user"><span class="menu-account-avatar" aria-hidden="true">${escapeHTML(initial)}</span><span class="menu-account-user-copy"><strong>${escapeHTML(displayName)}</strong><small dir="ltr">${escapeHTML(state.user.email || "")}</small></span></div>
        <div class="menu-account-details">${state.user.phone ? `<div><small>${t("phone")}</small><strong dir="ltr">${escapeHTML(state.user.phone)}</strong></div>` : ""}<div><small>${t("wallet")}</small><strong dir="ltr">${money(state.wallet)}</strong></div></div>
        <div class="menu-account-actions"><a class="btn small" href="#/account" data-action="close-menu">${t("accountTitle")}</a><button class="btn secondary small" type="button" data-action="logout">${t("signOut")}</button></div>
      </section>`;
    })() : `<section class="menu-account-card menu-account-guest" aria-label="${t("account")}">
      <div class="menu-account-guest-heading"><strong>${t("signIn")}</strong><small>${t("signInText")}</small></div>
      <a class="btn full" href="#/login" data-action="close-menu">${t("signIn")}</a>
      <p class="menu-account-signup">${t("noAccount")} <a href="#/register" data-action="close-menu">${t("signUp")}</a></p>
    </section>`;
    const overlay = document.createElement("div"); overlay.className = "modal-backdrop"; overlay.dataset.action = "close-menu";
    overlay.innerHTML = `<div class="mobile-menu-panel open" role="dialog" aria-modal="true" aria-label="${t("menu")}"><div class="inline-row">${brandMarkup()}<button class="lang-toggle" data-action="toggle-language">${t("language")}</button><button class="icon-button" data-action="close-menu" aria-label="${t("menu")}">${icon("close")}</button></div>${accountBlock}<nav class="menu-links" aria-label="${t("menu")}">${[["home", "/"], ["categories", "/categories"], ["products", "/products"], ["orders", "/orders"], ["favorites", "/favorites"], ["wallet", "/wallet"], ["support", "/support"], ["account", "/account"]].map(([key, url]) => `<a href="#${url}" data-action="close-menu">${t(key)}</a>`).join("")}</nav></div>`;
    document.getElementById("modal-root").appendChild(overlay);
  }
  function closeModal() { document.getElementById("modal-root").innerHTML = ""; }

  function copyText(value) { const text = String(value || ""); if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(() => toast(t("copied"))).catch(() => toast(t("shamCashCopyFailed"))); else { const input = document.createElement("textarea"); input.value = text; document.body.appendChild(input); input.select(); try { document.execCommand("copy"); toast(t("copied")); } catch (_) { toast(t("shamCashCopyFailed")); } input.remove(); } }
  function imageToDataUrl(file) { if (!file || !file.name) return Promise.resolve(""); return new Promise((resolve, reject) => { if (file.size > 3 * 1024 * 1024) return reject(new Error("حجم صورة الإيصال يجب أن يكون أقل من 3 ميغابايت.")); const reader = new FileReader(); reader.onload = () => resolve(String(reader.result || "")); reader.onerror = () => reject(new Error("تعذر قراءة صورة الإيصال.")); reader.readAsDataURL(file); }); }

  function showNotifications() {
    const rows = state.notifications.map((n) => `<div class="transaction"><span>${escapeHTML(n.text)}<small>${escapeHTML(n.time)}</small></span><span>•</span></div>`).join("") || `<p>${t("noTransactions")}</p>`;
    document.getElementById("modal-root").innerHTML = `<div class="modal-backdrop" data-action="close-modal"><div class="modal-card" role="dialog" aria-modal="true" aria-label="${t("notifications")}"><button class="modal-close" data-action="close-modal">×</button><h2>${t("notifications")}</h2><div class="wallet-transactions">${rows}</div></div></div>`;
  }
  function showDeposit() {
    if (!state.user) { navigate("/login"); toast(t("signInText")); return; }
    const walletNumber = SHAM_CASH.walletNumber ? `<strong class="shamcash-number" dir="ltr">${escapeHTML(SHAM_CASH.walletNumber)}</strong><button class="text-link" type="button" data-action="copy-shamcash">${t("shamCashCopy")}</button>` : `<strong class="shamcash-number unconfigured">${t("shamCashSetup")}</strong>`;
    document.getElementById("modal-root").innerHTML = `<div class="modal-backdrop" data-action="close-modal"><div class="modal-card deposit-modal" role="dialog" aria-modal="true" aria-label="${t("depositTitle")}"><button class="modal-close" data-action="close-modal">×</button><span class="eyebrow">${t("shamCashTitle")}</span><h2>${t("depositTitle")}</h2><div class="shamcash-transfer-box"><small>${t("shamCashNumber")}</small>${walletNumber}<p>${t("shamCashStep1")}</p></div><form id="deposit-form"><div class="field"><label for="deposit-amount">${t("shamCashAmount")} *</label><input id="deposit-amount" name="amount" type="number" required min="0.01" max="5000" step="0.01" inputmode="decimal" placeholder="10.00"><div class="deposit-estimate" id="deposit-estimate" aria-live="polite"><small>${t("shamCashEstimate")}</small><strong>${SHAM_CASH.exchangeRateSypPerUsd > 0 ? "—" : t("shamCashRateMissing")}</strong></div></div><div class="field"><label for="deposit-reference">${t("shamCashReference")} *</label><input id="deposit-reference" name="reference" maxlength="100" minlength="3" autocomplete="off" inputmode="text" required placeholder="0000000000"></div><div class="field"><label for="deposit-receipt">${t("shamCashReceipt")}</label><input id="deposit-receipt" name="receipt" type="file" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp"></div><p class="form-note">${t("shamCashReceiptNote")} ${t("demoDeposit")}</p><button class="btn full" type="submit" style="margin-top:16px">${t("sendRequest")}</button></form></div></div>`;
  }

  document.addEventListener("input", (event) => {
    if (event.target.id !== "deposit-amount") return;
    const estimate = document.getElementById("deposit-estimate");
    if (!estimate) return;
    const value = Number(event.target.value);
    const rate = Number(SHAM_CASH.exchangeRateSypPerUsd);
    const result = estimate.querySelector("strong");
    if (!rate || !Number.isFinite(rate)) result.textContent = t("shamCashRateMissing");
    else if (!Number.isFinite(value) || value <= 0) result.textContent = "—";
    else result.textContent = new Intl.NumberFormat(state.lang === "ar" ? "ar-SY" : "en-US", { maximumFractionDigits: 0 }).format(Math.round(value * rate)) + (state.lang === "ar" ? " ل.س" : " SYP");
  });

  document.addEventListener("click", (event) => {
    const actionEl = event.target.closest("[data-action]");
    if (!actionEl) return;
    const action = actionEl.dataset.action;
    if ((action === "close-menu" || action === "close-modal") && actionEl.classList.contains("modal-backdrop") && event.target !== actionEl) return;
    if (action === "toggle-language") { event.preventDefault(); setLang(state.lang === "ar" ? "en" : "ar"); }
    else if (action === "back") { event.preventDefault(); const route = parseRoute().split("/").filter(Boolean); if (route[0] === "product") { const p = productBySlug(route[1]); navigate(p ? "/category/" + p.category : "/products"); } else if (route[0] === "category") navigate("/categories"); else navigate("/"); }
    else if (action === "open-menu") openMenu();
    else if (action === "close-menu" || action === "close-modal") closeModal();
    else if (action === "notifications") showNotifications();
    else if (action === "focus-search") { const input = document.querySelector("#header-search-input, #search-input, #listing-search, #results-search"); if (input) { if (input.id === "header-search-input" && window.innerWidth <= 850) navigate("/search"); else { input.focus(); input.scrollIntoView({ behavior: "smooth", block: "center" }); } } else navigate("/search"); }
    else if (action === "toggle-password") { const input = document.getElementById(actionEl.dataset.passwordTarget); if (!input) return; const reveal = input.type === "password"; input.type = reveal ? "text" : "password"; actionEl.setAttribute("aria-pressed", String(reveal)); actionEl.setAttribute("aria-label", reveal ? (state.lang === "ar" ? "إخفاء كلمة المرور" : "Hide password") : (state.lang === "ar" ? "إظهار كلمة المرور" : "Show password")); actionEl.textContent = reveal ? (state.lang === "ar" ? "إخفاء" : "Hide") : (state.lang === "ar" ? "إظهار" : "Show"); }
    else if (action === "favorite") { event.preventDefault(); toggleFavorite(actionEl.dataset.slug); }
    else if (action === "buy") {
      const product = productBySlug(actionEl.dataset.slug); if (!product) return;
      if (product.kind === "topup") { navigate("/product/" + product.slug); toast(t("completeTopup")); return; }
      const optionIndex = Number(state.selectedOptions && state.selectedOptions[product.slug]) || 0;
      beginPurchase(product, optionIndex, 1, {}, actionEl);
    }
    else if (action === "option") { state.selectedOptions = state.selectedOptions || {}; state.selectedOptions[actionEl.dataset.slug] = Number(actionEl.dataset.index) || 0; save(); render(); }
    else if (action === "qty-minus" || action === "qty-plus") { const input = document.getElementById("product-qty"); if (input) input.value = String(Math.max(1, Math.min(10, Number(input.value) + (action === "qty-plus" ? 1 : -1)))); }
    else if (action === "remove-cart") { state.cart = state.cart.filter((item) => item.key !== actionEl.dataset.key); save(); render(); }
    else if (action === "save-cart") { const item = state.cart.find((x) => x.key === actionEl.dataset.key); if (item && !state.favorites.includes(item.slug)) state.favorites.push(item.slug); state.cart = state.cart.filter((x) => x.key !== actionEl.dataset.key); save(); render(); toast(t("wishlist")); }
    else if (action === "cart-qty") { const item = state.cart.find((x) => x.key === actionEl.dataset.key); if (item) { item.qty = Math.max(1, Math.min(10, item.qty + Number(actionEl.dataset.change))); save(); render(); } }
    else if (action === "apply-promo") { const code = (document.getElementById("promo-code")?.value || "").trim().toUpperCase(); if (code === "WELCOME10") { state.promo = code; state.promoRate = .1; save(); render(); toast(t("promoApplied")); } else { state.promo = ""; state.promoRate = 0; save(); toast(t("promoInvalid")); } }
    else if (action === "checkout") { state.checkoutStep = 1; save(); navigate("/checkout"); }
    else if (action === "checkout-back") { state.checkoutStep = Math.max(1, state.checkoutStep - 1); save(); render(); }
    else if (action === "place-order") placeOrder();
    else if (action === "add-funds") showDeposit();
    else if (action === "copy-support") { copyText(ASSETS.supportPhone || "+963992761983"); }
    else if (action === "copy-shamcash") {
      if (!SHAM_CASH.walletNumber) { toast(t("shamCashSetup")); return; }
      copyText(SHAM_CASH.walletNumber);
    }
    else if (action === "logout") { window.StoreAPI.logout().then(() => { state.user = null; state.wallet = 0; state.orders = []; state.transactions = []; state.pendingPurchase = null; state.checkoutData = {}; save(); closeModal(); render(); toast(t("signOut")); }).catch((error) => toast(error.message)); }

    else if (action === "invoice") { toast(`${t("invoice")} · ${actionEl.dataset.id}`); }
    else if (action === "detail-tab") { document.querySelectorAll(".detail-tabs button").forEach((el) => el.classList.toggle("active", el === actionEl)); const box = document.getElementById("detail-tab-content"); if (box) box.innerHTML = `<p>${actionEl.dataset.tab === "instructions" ? t("faqAnswerOrder") : actionEl.dataset.tab === "faq" ? t("faq1a") : t("description")}</p>`; }
    else if (action === "clear-filters") { const max = document.getElementById("max-price"); if (max) max.value = ""; const input = document.querySelector("[data-filter='sort']"); if (input) input.value = "popular"; applyFilters(); }
  });

  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (["search-form", "header-search-form"].includes(form.id)) { event.preventDefault(); const query = new FormData(form).get("q") || ""; navigate(`/search?q=${encodeURIComponent(query)}`); }
    else if (form.id === "product-form") {
      event.preventDefault(); if (!form.reportValidity()) return;
      const product = productBySlug(form.dataset.slug); if (!product) return;
      const fd = new FormData(form); const index = (state.selectedOptions && state.selectedOptions[product.slug]) || 0; const qty = Math.max(1, Math.min(10, Number(fd.get("qty")) || 1));
      beginPurchase(product, index, qty, { playerId: fd.get("playerId") || "", server: fd.get("server") || "", username: fd.get("username") || "", accountEmail: fd.get("accountEmail") || "" }, event.submitter);
    }
    else if (form.id === "checkout-form") {
      event.preventDefault();
      if (state.checkoutStep === 1) { if (!form.reportValidity()) return; const fd = new FormData(form); state.checkoutData = { name: fd.get("name"), email: fd.get("email"), phone: fd.get("phone") }; }
      if (state.checkoutStep === 3) {
        state.paymentMethod = new FormData(form).get("payment") || "shamcash";
        if (state.paymentMethod === "wallet" && state.wallet + 0.001 < cartTotal()) { toast(t("walletInsufficient")); return; }
      }
      state.checkoutStep = Math.min(4, state.checkoutStep + 1); save(); render();
    }
    else if (form.id === "auth-form") {
      event.preventDefault(); if (!form.reportValidity()) return;
      const fd = new FormData(form);
      if (fd.get("confirm") && fd.get("confirm") !== fd.get("password")) { toast(t("confirmPassword")); return; }
      const register = fd.get("confirm") !== null;
      const body = { name: fd.get("name"), phone: fd.get("phone"), email: fd.get("email"), password: fd.get("password") };
      if (!window.StoreAPI) { toast(t("noBackend")); return; }
      const submitButton = event.submitter || form.querySelector(".auth-submit");
      const submitLabel = submitButton && submitButton.querySelector(".auth-submit-label");
      const idleLabel = submitLabel ? submitLabel.textContent : "";
      const restoreSubmit = () => { if (!submitButton) return; submitButton.disabled = false; submitButton.classList.remove("is-loading"); submitButton.removeAttribute("aria-busy"); if (submitLabel) submitLabel.textContent = idleLabel; };
      if (submitButton) { submitButton.disabled = true; submitButton.classList.add("is-loading"); submitButton.setAttribute("aria-busy", "true"); if (submitLabel) submitLabel.textContent = register ? (state.lang === "ar" ? "جارٍ إنشاء الحساب…" : "Creating account…") : (state.lang === "ar" ? "جارٍ تسجيل الدخول…" : "Signing in…"); }
      (register ? window.StoreAPI.register(body) : window.StoreAPI.login(body)).then((result) => {
        state.user = result.user; state.wallet = Number(result.user.balance || 0); state.checkoutData = { name: result.user.name, email: result.user.email, phone: result.user.phone }; const pending = state.pendingPurchase; save();
        if (pending) submitPurchase(pending).finally(restoreSubmit);
        else { navigate("/account"); toast(t("authSuccess")); }
      }).catch((error) => { restoreSubmit(); toast(error.message); });
    }
    else if (form.id === "deposit-form") {
      event.preventDefault(); if (!form.reportValidity()) return;
      if (!state.user) { navigate("/login"); toast(t("signInText")); return; }
      const fd = new FormData(form), file = fd.get("receipt"), amount = Number(fd.get("amount"));
      imageToDataUrl(file).then((receiptData) => window.StoreAPI.deposit({ amount, reference: String(fd.get("reference") || "").trim(), receiptData })).then((result) => {
        const d = result.deposit; state.transactions.unshift({ id: d.id, type: "deposit", title: t("walletDeposit"), amount: d.amount, reference: d.reference, date: new Date(d.createdAt).toLocaleDateString(), status: t("pending"), receiptName: file && file.name || "" }); state.notifications.unshift({ id: Date.now(), text: t("walletDeposit") + " · " + t("pending"), time: new Date().toLocaleTimeString() }); save(); closeModal(); render(); toast(t("depositPending"));
      }).catch((error) => toast(error.message));
    }
    else if (form.id === "ticket-form") {
      event.preventDefault(); if (!form.reportValidity()) return;
      const fd = new FormData(form);
      window.StoreAPI.ticket({ subject: fd.get("subject"), message: fd.get("message"), name: fd.get("name"), email: fd.get("email"), phone: fd.get("phone") }).then(() => { form.reset(); toast(t("ticketSaved")); }).catch((error) => toast(error.message));
    }
  });

  document.addEventListener("input", (event) => {
    if (event.target.matches("#search-input, #listing-search, #results-search, #header-search-input")) {
      const query = event.target.value.trim(); const box = event.target.closest("form").querySelector(".search-suggestions");
      if (!box) return;
      const matches = query ? searchProducts(query.toLowerCase()).slice(0, 5) : [];
      box.innerHTML = matches.map((p) => `<a class="suggestion" href="#/product/${p.slug}"><img src="${p.image}" alt="" loading="lazy"><span>${escapeHTML(label(p.title))}<small>${escapeHTML(catName(categoryById(p.category)))} · ${money(getOption(p).price)}</small></span></a>`).join("") || (query ? `<div class="suggestion">${t("noResults")}</div>` : "");
      box.classList.toggle("open", !!query);
    }
    if (event.target.matches("[data-filter='max-price']")) applyFilters();
  });
  document.addEventListener("change", (event) => { if (event.target.matches("[data-filter='sort']")) applyFilters(); if (event.target.name === "payment") state.paymentMethod = event.target.value; save(); });

  function applyFilters() {
    const container = document.getElementById("filter-results"); if (!container) return;
    const max = Number(document.getElementById("max-price")?.value) || Infinity;
    const sort = document.querySelector("[data-filter='sort']")?.value || "popular";
    const raw = location.hash.slice(1); const q = new URLSearchParams(raw.split("?")[1] || "").get("q") || "";
    const categoryId = raw.startsWith("/category/") ? raw.split("/")[2] : "";
    const category = categoryById(categoryId);
    let list = categoryId ? PRODUCTS.filter((p) => p.category === categoryId || (category && category.platform && p.platform === category.platform) || (categoryId === "mobile" && p.kind === "topup")) : searchProducts(q.toLowerCase());
    list = list.filter((p) => getOption(p).price <= max);
    if (sort === "price-up") list.sort((a, b) => a.price - b.price);
    else if (sort === "price-down") list.sort((a, b) => b.price - a.price);
    else if (sort === "newest") list.reverse();
    container.innerHTML = renderProductGrid(list);
  }

  async function placeOrder() {
    if (!state.cart.length) { navigate("/products"); return; }
    if (!window.StoreAPI) { toast(t("noBackend")); return; }
    const items = state.cart.map((item) => {
      const product = productBySlug(item.slug);
      const optionIndex = product && product.options ? Math.max(0, product.options.findIndex((option) => label(option) === item.option)) : 0;
      return { productId: product ? product.id : item.slug, slug: item.slug, optionIndex, quantity: item.qty, playerId: item.details && item.details.playerId || "", server: item.details && item.details.server || "", username: item.details && item.details.username || "", accountEmail: item.details && item.details.accountEmail || "" };
    });
    try {
      const response = await window.StoreAPI.order({ customer: state.checkoutData, items, paymentMethod: state.paymentMethod === "wallet" ? "wallet" : "shamcash" });
      const saved = response.order;
      const order = { id: saved.id, date: new Date(saved.createdAt).toLocaleDateString(), createdAt: saved.createdAt, total: saved.total, items: saved.items.map((item) => ({ slug: item.slug, qty: item.quantity, title: item.title })), status: saved.status, paymentMethod: saved.paymentMethod, paymentStatus: saved.paymentStatus, deliveryStatus: saved.deliveryStatus };
      state.orders.unshift(order);
      if (response.balance !== null) state.wallet = Number(response.balance);
      if (saved.paymentMethod === "wallet") state.transactions.unshift({ id: saved.id, type: "purchase", title: t("walletPurchase"), amount: -saved.total, date: order.date, status: t("completed") });
      state.cart = []; state.promo = ""; state.promoRate = 0; state.checkoutStep = 1; save(); navigate("/orders"); toast(t("orderCreated"));
    } catch (error) { toast(error.message); }
  }

  async function initializeStore() {
    render(); if (!window.StoreAPI) return;
    if (location.protocol === "file:" && !window.StoreAPI.baseUrl) { toast(state.lang === "ar" ? "لتفعيل الحساب والمحفظة، افتح المتجر عبر http://localhost:4173" : "Open the store at http://localhost:4173 to enable accounts and wallet features."); return; }
    try {
      const results = await Promise.all([window.StoreAPI.config(), window.StoreAPI.products()]);
      const config = results[0], products = results[1];
      if (Array.isArray(products) && products.length) PRODUCTS = products.map((product) => Object.assign({}, product, { image: String(product.image || "").startsWith("/") ? location.origin + product.image : product.image }));
      if (config.settings) { SHAM_CASH.walletNumber = config.settings.shamCashAccount || SHAM_CASH.walletNumber; SHAM_CASH.exchangeRateSypPerUsd = Number(config.settings.exchangeRateSypPerUsd || 0); ASSETS.supportPhone = config.settings.supportPhone || "+963992761983"; ASSETS.supportUrl = "https://wa.me/" + ASSETS.supportPhone.replace(/[^0-9]/g, ""); const images = config.settings.categoryImages || {}; for (const category of CATEGORIES) { const image = images[category.id]; category.image = image ? location.origin + image : DEFAULT_CATEGORY_IMAGES[category.id]; } }
      try {
        const me = await window.StoreAPI.me(); state.user = me.user; state.wallet = Number(me.user.balance || 0);
        state.orders = me.orders.map((order) => ({ id: order.id, date: new Date(order.createdAt).toLocaleDateString(), createdAt: order.createdAt, total: order.total, items: order.items.map((item) => ({ slug: item.slug, qty: item.quantity, title: item.title })), status: order.status, paymentMethod: order.paymentMethod, paymentStatus: order.paymentStatus, deliveryStatus: order.deliveryStatus }));
        state.transactions = (me.deposits || []).map((deposit) => ({ id: deposit.id, type: "deposit", title: t("walletDeposit"), amount: deposit.amount, reference: deposit.reference, date: new Date(deposit.createdAt).toLocaleDateString(), status: deposit.status, receiptName: deposit.hasReceipt ? "إيصال مرفق" : "" }));
        state.checkoutData = { name: me.user.name, email: me.user.email, phone: me.user.phone };
      } catch (_) { state.user = null; state.wallet = 0; }
      if (!state.user || state.paymentMethod !== "wallet") state.paymentMethod = "shamcash"; save(); render();
    } catch (error) { console.warn("Store API is not connected:", error.message); }
  }

  window.addEventListener("hashchange", () => { closeModal(); render(); window.scrollTo({ top: 0, behavior: "smooth" }); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeModal(); });
  initializeStore();
})();
